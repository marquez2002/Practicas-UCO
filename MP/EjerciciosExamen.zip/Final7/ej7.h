#ifndef __ej7__
#define __ej7__
void ordenacion(char const* archivo1, char const* archivo2);
void escribirFicherobin(char const* archivo1, int nEle);
#endif