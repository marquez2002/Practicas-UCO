#include "ej7.h"
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

void escribirFicherobin(char const* archivo1, int nEle){
    FILE* f;
    srand(time(NULL));
    f=fopen(archivo1, "wb");
    int* vector;
    if((vector=(int*)calloc(nEle, sizeof(int)))==NULL){
        printf("ERROR al crear el vector dinamico\n");
        exit(0);
    }
    for(int i=0; i<nEle; i++){
        vector[i]=rand()%25;
        printf("%d ", vector[i]);
    }
    printf("\n");
    fwrite(vector, sizeof(int), nEle, f);
    fclose(f);
}

void ordenacion(char const* archivo1, char const* archivo2){
    int* vector;
    FILE *f1;
    FILE *f2;
    f1=fopen(archivo1, "rb");
    f2=fopen(archivo2, "w");
    fseek(f1, 0, SEEK_END);
    int nEle=(ftell(f1)/sizeof(int));
    fclose(f1);
    if((vector=(int*)malloc(nEle*sizeof(int)))==NULL){
        printf("ERROR al generar el vector dinamico\n");
        exit(0);
    }
    f1=fopen(archivo1, "rb");
    fread(vector, sizeof(int), nEle, f1);
    fclose(f1);

    for(int i=0; i<(nEle-1); i++){
        for(int j=i+1; j<nEle; j++){
            if(vector[i]>vector[j]){
                int aux=vector[i];
                vector[i]=vector[j];
                vector[j]=aux;
            }
        }
    }
    for(int i=0; i<nEle; i++){
        fprintf(f2, "%d\n", vector[i]);
    }
    fclose(f2);
}