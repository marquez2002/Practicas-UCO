#include "ej7.h"
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char const* argv[]){
    if(argc<3){
        printf("ERROR al introducir los archivos\n");
        return -1;
    }
    
    FILE* f1;
    FILE* f2;
    if((f1=fopen(argv[1], "wb"))==NULL){
        printf("ERROR al abrir el archivo\n");
        return -1;
    }
    fclose(f1);
    if((f1=fopen(argv[1], "rb"))==NULL){
        printf("ERROR al abrir el archivo\n");
        return -1;
    }
    if((f2=fopen(argv[2], "w"))==NULL){
        printf("ERROR al abrir el archivo\n");
        return -1;
    }

    fclose(f1);
    fclose(f2);
    int nEle=20;
    escribirFicherobin(argv[1], nEle);
    ordenacion(argv[1], argv[2]);
}