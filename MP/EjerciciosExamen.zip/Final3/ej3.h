#ifndef __ej3__
#define __ej3__
#define LENGTH 100
struct datos{
    int codigo;
    char nombre[LENGTH];
};

struct lista{
    int codigo;
    char nombre[LENGTH];
    struct lista* sig;
};
struct lista* nuevoElemento();
int ejercicio3(int nElem1, int nElem2, struct datos* C1, struct datos* C2, struct lista* LP);
void insertarFinal(struct lista** LP, int codigo, char* nombre);
void imprimir(struct lista* LP);
#endif
