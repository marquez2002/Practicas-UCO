#include "ej3.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(){
    struct datos* C1;
    struct datos* C2;
    struct lista* LP=NULL;   
    int nElem1=3, nElem2=3;
    if((C1=(struct datos*)calloc(nElem1, sizeof(struct datos)))==NULL){
        printf("ERROR\n");
        return -1;
    }
    if((C2=(struct datos*)calloc(nElem2, sizeof(struct datos)))==NULL){
        printf("ERROR\n");
        return -1;
    }
    int codigo;
    char nombrecopia[LENGTH];
    printf("VECTOR 1: \n");
    for(int i=0; i<nElem1; i++){
        printf("Introducir codigo: ");
        scanf("%d", &C1[i].codigo);
        printf("Introducir nombre: ");
        scanf("%s", C1[i].nombre);
        codigo=C1[i].codigo;
        strcpy(nombrecopia, C1[i].nombre);
        insertarFinal(&LP, codigo, nombrecopia);
    }
    printf("\nVECTOR 2: \n");
    for(int i=0; i<nElem2; i++){
        printf("Introducir codigo: ");
        scanf("%d", &C2[i].codigo);
        printf("Introducir nombre: ");
        scanf("%s", C2[i].nombre);
        codigo=C2[i].codigo;
        strcpy(nombrecopia, C2[i].nombre);
        insertarFinal(&LP, codigo, nombrecopia);
    }
    int alumnos=ejercicio3(nElem1, nElem2, C1, C2, LP);
    printf("Alumnos: %d\n", alumnos);
    imprimir(LP);


}