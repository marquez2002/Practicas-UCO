#include "ej3.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct lista* nuevoElemento(){
    return ((struct lista*)malloc(sizeof(struct lista)));
}

int ejercicio3(int nElem1, int nElem2, struct datos* C1, struct datos* C2, struct lista * LP){
    int nElem3=nElem1+nElem2;
    return nElem3;
}

void insertarFinal(struct lista** LP, int codigo, char* nombre){
    struct lista* aux=NULL;
    struct lista* nuevo=NULL;
    nuevo=nuevoElemento();
    nuevo->codigo=codigo;
    strcpy(nuevo->nombre, nombre);
    nuevo->sig=NULL;
    if(*LP==NULL){
        *LP=nuevo;
    }
    else{
        aux=*LP;
        while(aux->sig!=NULL){
            aux=aux->sig;
        }
        aux->sig=nuevo;
    }
}

void imprimir(struct lista* LP){
    struct lista *aux=NULL;
    aux=LP;
    while(aux!=NULL){
        printf("Codigo: %d   Nombre: %s\n", aux->codigo, aux->nombre);
        aux=aux->sig;
    }
}