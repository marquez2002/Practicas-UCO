#include "ej5.h"
#include <stdio.h>
#include <stdlib.h>

int main(){
    int nEle;
    printf("Introduce nº elementos vector: ");
    scanf("%d", &nEle);
    float* vector;  
    if((vector=(float*)calloc(nEle, sizeof(float)))==NULL){
        printf("ERROR\n");
        exit(0);
    }

    rellenarVector(vector, nEle);
    imprimeVector(vector, nEle);
    printf("\n");    
    ordenarVector(vector, nEle);
    imprimeVector(vector, nEle);
    printf("\n");    
    free(vector);
}