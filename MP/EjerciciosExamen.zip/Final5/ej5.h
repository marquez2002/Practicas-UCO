#ifndef __ej5__
#define __ej5__
void rellenarVector(float* vector, int nEle);
void imprimeVector(float* vector, int nEle);
void ordenarVector(float* vector, int nEle);
#endif