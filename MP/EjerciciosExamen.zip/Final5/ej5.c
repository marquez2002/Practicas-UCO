#include "ej5.h"
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

void rellenarVector(float* vector, int nEle){
    srand(time(NULL));
    for(int i=0; i<nEle; i++){
        vector[i]=(rand()%25)+1;
    }
}

void imprimeVector(float* vector, int nEle){
    if(nEle-1>=1){
        imprimeVector(vector, nEle-1);
        printf("v[%d]=%f \n", nEle-1, vector[nEle-1]);
    }
}

void ordenarVector(float* vector, int nEle){
    for(int i=0; i<(nEle-1); i++){
        for(int j=i+1; j<nEle; j++){
            if(vector[i]>vector[j]){
                int aux=vector[i];
                vector[i]=vector[j];
                vector[j]=aux;
            }
        }
    }
}