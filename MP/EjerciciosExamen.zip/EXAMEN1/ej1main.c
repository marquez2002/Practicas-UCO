#include "ej1.h"
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char const* argv[]){
    if(argc<3){
        printf("ERROR al ejecutar, recuerda introducir los archivos\n");
        return -1;
    }
    int nEle;
    printf("ELEMENTOS DEL VECTOR: ");
    scanf("%d", &nEle);
    int* vector;
    if((vector=(int*)calloc(nEle, sizeof(int)))==NULL){
        printf("ERROR AL RESERVAR EL VECTOR\n");
        return -1;
    }

    rellenarVector(vector, nEle);
    FILE* f1;
    if((f1=fopen(argv[1], "wb"))==NULL){
        printf("ERROR AL RESERVAR EL ARCHIVO 1\n");
        return -1;
    }
    fclose(f1);
    crearBinario(argv[1], vector, nEle);

    FILE* f2;
    if((f1=fopen(argv[1], "rb"))==NULL){
        printf("ERROR AL RESERVAR EL ARCHIVO 1\n");
        return -1;
    }
    if((f2=fopen(argv[2], "w"))==NULL){
        printf("ERROR AL RESERVAR EL ARCHIVO 2\n");
        return -1;
    }

    pasarBinarioTexto(argv[1], argv[2]);
  

}