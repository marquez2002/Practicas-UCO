#ifndef __ej1__
#define __ej1__
struct lista{
    int num;
    struct lista* sig;
};
struct lista* nuevoElemento();
void imprimirLista(struct lista* numeros);
void rellenarFINAL(struct lista** numeros, int n);
void contarMayorMenor(struct lista* numeros, int* nM, int* nm);
void contarPos_Neg(struct lista* numeros, int* positivos, int* negativos);
#endif