#include "ej2.h"
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main(){
    srand(time(NULL));
    int nEle;
    printf("Indique cuantos elementos tiene la lista: ");
    scanf("%d", &nEle);

    struct lista* numeros=NULL;

    for(int i=0; i<nEle; i++){
        int n=((rand()%25)+1);
        rellenarFINAL(&numeros, n);
    }
    imprimirLista(numeros);
    int mayor, menor;
    contarMayorMenor(numeros, &mayor, &menor);
    int positivos=0, negativos=0;
    contarPos_Neg(numeros, &positivos, &negativos);
    printf("Habra %d positivos y %d negativos, siendo el mayor %d y el menor %d\n", positivos, negativos, mayor, menor);

}