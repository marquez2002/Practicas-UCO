#include "ej1.h"
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

void rellenarVector(int* vector, int nEle){
    srand(time(NULL));
    for(int i=0; i<nEle; i++){
        vector[i]=((rand()%25)+1);
        printf("%d\n", vector[i]);
    }
    printf("\n");
}

void crearBinario(char const* archivo, int* vector, int nEle){
    FILE* f;
    f=fopen(archivo, "wb");
    fwrite(vector, sizeof(int), nEle, f);
    fclose(f);
}

void pasarBinarioTexto(char const* archivo1, char const* archivo2){
    FILE* f1;
    FILE* f2;
    f1=fopen(archivo1, "rb");
    f2=fopen(archivo2, "w");
    fseek(f1, 0, SEEK_END);
    int nEle=((ftell(f1)/sizeof(int)));
    fclose(f1);
    int* vector;
    if((vector=(int*)calloc(nEle, sizeof(int)))==NULL){
        printf("ERROR AL CREAR VECTOR DINAMICO\n");
        exit(0);
    }
    f1=fopen(archivo1, "rb");
    fread(vector, sizeof(int), nEle, f1);
    ordenarVector(vector, nEle);
    for(int i=0; i<nEle; i++){
        fprintf(f2, "%d\n", vector[i]);
    }
}

void ordenarVector(int* vector, int nEle){
    for(int i=0; i<(nEle-1); i++){
        for(int j=i+1; j<nEle; j++){
            if(vector[i]>vector[j]){
                int aux=vector[i];
                vector[i]=vector[j];
                vector[j]=aux;
            }
        }
    }
}