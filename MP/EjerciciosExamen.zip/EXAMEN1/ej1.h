#ifndef __ej1__
#define __ej1__
void rellenarVector(int* vector, int nEle);
void crearBinario(char const* archivo, int* vector, int nEle);
void pasarBinarioTexto(char const* archivo1, char const* archivo2);
void ordenarVector(int* vector, int nEle);
#endif