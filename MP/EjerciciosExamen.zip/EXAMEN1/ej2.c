#include "ej2.h"
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

struct lista* nuevoElemento(){
    return ((struct lista*)malloc(sizeof(struct lista)));
}


void rellenarFINAL(struct lista** numeros, int n){
    struct lista* nuevo=NULL;
    struct lista* aux=NULL;
    nuevo=nuevoElemento();
    nuevo->num=n;
    nuevo->sig=NULL;
    if(*numeros==NULL){
        *numeros=nuevo;
    }
    else{
        aux=*numeros;
        while(aux->sig!=NULL){
            aux=aux->sig;
        }
        aux->sig=nuevo;
    }
}

void imprimirLista(struct lista* numeros){
    struct lista* aux=NULL;
    aux=numeros;
    while(aux!=NULL){
        printf("%d\n", aux->num);
        aux=aux->sig;
    }
}

void contarMayorMenor(struct lista* numeros, int* nM, int* nm){
    struct lista* aux=NULL;
    aux=numeros;
    *nM=aux->num;
    *nm=aux->num;
    while(aux->sig!=NULL){
        if(*nM<aux->num){
            *nM=aux->num;
        }
        if(*nm>aux->num){
            *nm=aux->num;
        }
        aux=aux->sig;
    }
    if(*nM<aux->num){
        *nM=aux->num;
    }
    if(*nm>aux->num){
        *nm=aux->num;
    }
}

void contarPos_Neg(struct lista* numeros, int* positivos, int* negativos){
    struct lista* aux=NULL;
    struct lista* aux2=NULL;
    aux=numeros;
    aux2=numeros;
    printf("Positivos: \n");
    while(aux!=NULL){
        if(aux->num%2==0){
            *positivos=*positivos+1;
            printf("%d\n", aux->num);
        }
        aux=aux->sig;
    }
    printf("Negativos: \n");
    while(aux2!=NULL){
        if(aux2->num%2!=0){
            *negativos=*negativos+1;
            printf("%d\n", aux2->num);
        }
        aux2=aux2->sig;
    }
}