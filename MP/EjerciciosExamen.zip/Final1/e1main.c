#include "ej1.h"
#include <stdio.h>
#include <stdlib.h> 

int main(){
    struct nomina* Vector;
    int nEle=3;
    if((Vector=(struct nomina*)calloc(nEle, sizeof(struct nomina)))==NULL){
        printf("ERROR\n");
        return -1;
    }
    for(int i=0; i<nEle; i++){
        printf("Introduce codigo: ");
        scanf("%d", &Vector[i].codigo);
        printf("Introduce nombre: ");
        scanf("%s", Vector[i].nombre);
        printf("Introduce retenciones: ");
        scanf("%f", &Vector[i].retenciones);
        printf("Introduce sal. bruto: ");
        scanf("%f", &Vector[i].salarioBruto);
    }
    int criterio;
    printf("Valor de criterio: ");
    scanf("%d", &criterio);
    apartado1(nEle, Vector, criterio);
    apartado2(nEle, Vector);

}