#include "ej1.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void apartado1(int nEle, struct nomina* Vector, int criterio){
    int (*funcion)(const void*, const void*);
    if(criterio==0){
        funcion=&Ascendente;
    }
    else{
        funcion=&Descendente;
    }
    qsort(Vector, nEle, sizeof(struct nomina), funcion);
}

int Ascendente(const void* a, const void* b){
    float retencionesA=(*(struct nomina*)a).retenciones;
    float retencionesB=(*(struct nomina*)b).retenciones;

    float salariobrutoA=(*(struct nomina*)a).salarioBruto;
    float salariobrutoB=(*(struct nomina*)b).salarioBruto;

    float salarionetoA=salariobrutoA-salariobrutoA*(retencionesA/100);
    float salarionetoB=salariobrutoB-salariobrutoB*(retencionesB/100);

    float criterio=salarionetoA-salarionetoB;
    
    if(criterio>0){
        return 1;
    }

    if(criterio==0){
        return 0;
    }

    if(criterio<0){
        return -1;
    }
}

int Descendente(const void* a, const void* b){
    char* nombreA=(*(struct nomina*)a).nombre;
    char* nombreB=(*(struct nomina*)b).nombre;
    return (strcmp(nombreA, nombreB));
}

void apartado2(int nEle, struct nomina* Vector){
    if(nEle<1){
        exit(0);
    }
    printf("%d %s %f %f\n", Vector[nEle-1].codigo, Vector[nEle-1].nombre, Vector[nEle-1].retenciones, Vector[nEle-1].salarioBruto);
    apartado2(nEle-1, Vector);
}