#ifndef __ej1__
#define __ej1__
#define LENGTH 100
struct nomina{
    int codigo;
    char nombre[LENGTH];
    float retenciones;
    float salarioBruto;
};
void apartado1(int nEle, struct nomina* Vector, int criterio);
int Ascendente(const void* a, const void* b);
int Descendente(const void* a, const void* b);
void apartado2(int nEle, struct nomina* Vector);
#endif