#include "ej9.h"
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

struct lista *nuevoElemento(){
    return ((struct lista*)malloc(sizeof(struct lista)));
}

void insertarDelante(struct lista **number, int n){
    struct lista *nuevo=NULL;
    struct lista *aux=NULL;
    nuevo=nuevoElemento();
    nuevo->nums=n;
    nuevo->sig=NULL;
    if(*number==NULL){
        *number=nuevo;
    }
    else{
        aux=*number;
        while(aux->sig!=NULL){
            aux=aux->sig;
        }
        aux->sig=nuevo;
    }

    
}

void imprimirLista(struct lista* cabeza){
    struct lista *aux=NULL;
    aux=cabeza;
    while(aux!=NULL){
        printf("%d\n", aux->nums);
        aux=aux->sig;
    }
}

void mayormenor(struct lista* number, int *min, int *max){
    struct lista* aux=NULL;
    aux=number;
    *min=aux->nums;
    *max=aux->nums;
    while(aux->sig!=NULL){
        if(*min>aux->nums){
            *min=aux->nums;
        }
        if(*max<aux->nums){
            *max=aux->nums;
        }
        aux=aux->sig;
    }
    if(*min>aux->nums){
            *min=aux->nums;
        }
    if(*max<aux->nums){
        *max=aux->nums;
    }
}

void conteo(struct lista* number, int* positivos, int* negativos){
    struct lista* aux=NULL;
    struct lista* aux2=NULL;
    aux=number;
    aux2=number;
    printf("\nPOSITIVOS\n");
    while(aux->sig!=NULL){
        if(aux->nums%2==0){
            printf("%d\n", aux->nums);
            *positivos=*positivos+1;
        }
        aux=aux->sig;
    }
    if(aux->nums%2==0){
            printf("%d\n", aux->nums);
            *positivos=*positivos+1;
        }
    

    printf("\nNEGATIVOS\n");
    while(aux2->sig!=NULL){
        if(aux2->nums%2!=0){
            printf("%d\n", aux2->nums);
            *negativos=*negativos+1;
        }
        aux2=aux2->sig;
    }
    if(aux2->nums%2!=0){
            printf("%d\n", aux2->nums);
            *negativos=*negativos+1;
    }   
}