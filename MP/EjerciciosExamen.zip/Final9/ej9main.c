#include "ej9.h"
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main(){
    srand(time(NULL));
    int n, nEle;
    struct lista *number=NULL;
    printf("Elementos a insertar: ");
    scanf("%d", &nEle);
    for(int i=0; i<nEle;i++){
        n=((rand()%25)+1);
        insertarDelante(&number, n);
    }
    imprimirLista(number);
    int min, max;
    mayormenor(number, &min, &max);
    printf("El elemento mayor es %d y el menor %d\n", max, min);
    int positivos=0, negativos=0;
    conteo(number, &positivos, &negativos);
    printf("Habra %d numeros positivos y %d negativos\n", positivos, negativos);
}