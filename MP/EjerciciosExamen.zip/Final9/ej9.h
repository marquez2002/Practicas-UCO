#ifndef __ej9__
#define __ej9__
struct lista{
    int nums;
    struct lista* sig;
};
struct lista *nuevoElemento();
void insertarDelante(struct lista **cabeza, int n);
void imprimirLista(struct lista* cabeza);
void mayormenor(struct lista* number, int *min, int *max);
void conteo(struct lista* number, int* positivos, int* negativos);
#endif