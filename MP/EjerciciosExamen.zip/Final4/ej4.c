#include "ej4.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void ejercicio2(int nElem, int vector[], int criterio){
    if(criterio==0){
        for(int i=0; i<(nElem-1); i++){
            for(int j=i+1; j<nElem; j++){
                if(vector[i]<vector[j]){
                    int aux=vector[i];
                    vector[i]=vector[j];
                    vector[j]=aux;
                }
            }
        }
    }
    else{
        for(int i=0; i<(nElem-1); i++){
            for(int j=i+1; j<nElem; j++){
                if(vector[i]>vector[j]){
                    int aux=vector[i];
                    vector[i]=vector[j];
                    vector[j]=aux;
                }
            }
        }
    }          
}

void printf_vect(int nElem, int vector[]){
    if(nElem-1>=0){
        printf_vect(nElem-1, vector);
        printf("v[%d]=%d\n", nElem-1, vector[nElem-1]);
    }
}