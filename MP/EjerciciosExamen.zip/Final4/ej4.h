#ifndef __ej3__
#define __ej3__
void ejercicio2(int nElem, int vector[], int criterio);
void printf_vect(int nElem, int vector[]);
#endif