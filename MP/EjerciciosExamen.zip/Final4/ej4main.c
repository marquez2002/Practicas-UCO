#include "ej4.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

int main(){
    int nElem;
    srand(time(NULL));
    printf("Introduce el numero de elementos: ");
    scanf("%d", &nElem);
    int vector[nElem];
    for(int i=0; i<nElem; i++){
        vector[i]=(rand()%10)+1;
    }
    printf("VECTOR DESORDENADO\n");
    printf_vect(nElem, vector);
    printf("\n");

    int criterio;
    printf("Criterio=0 -> Descendente\n");
    printf("Criterio!=0 -> Ascendente\n");
    printf("Criterio: ");
    scanf("%d", &criterio);

    ejercicio2(nElem, vector, criterio);
    
    printf("\n");
    printf("VECTOR ORDENADO\n");
    printf_vect(nElem, vector);
    printf("\n");
    


}