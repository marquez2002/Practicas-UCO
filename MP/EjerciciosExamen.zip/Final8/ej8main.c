#include "ej8.h"
#include <stdio.h>
#include <stdlib.h>

int main(){
    int nEle;
    printf("¿Cuantos elementos tiene el vector?: ");
    scanf("%d", &nEle);
    int criterio;
    printf("¿Criterio de ordenacion?:\n0. Ascendente\n1. Descendente\n");
    scanf("%d", &criterio);

    
    int* vector;
    if((vector=(int*)calloc(nEle, sizeof(int)))==NULL){
        printf("ERROR al generar vector dinamico\n");
        return -1;
    }

    rellenarVector(vector, nEle);
    imprimirVector(vector, nEle);
    ordenarVector(vector, nEle, criterio);
    imprimirVector(vector, nEle);


}