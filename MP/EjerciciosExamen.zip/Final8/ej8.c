#include "ej8.h"
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

void rellenarVector(int* vector, int nEle){
    srand(time(NULL));
    for(int i=0; i<nEle; i++){
        vector[i]=(rand()%10)+1;
    }
}

void imprimirVector(int* vector, int nEle){
    for(int i=0; i<nEle; i++){
        printf("v[%d]=%d\n", i, vector[i]);
    }
    printf("\n");
}

void ordenarVector(int* vector, int nEle, int criterio){
    for(int i=0; i<(nEle-1); i++){
        if(criterio==0){
            for(int j=i+1; j<nEle;j++){
                if(vector[i]>vector[j]){
                    int aux=vector[i];
                    vector[i]=vector[j];
                    vector[j]=aux;
                }
            }
        }
        else{
            for(int j=i+1; j<nEle;j++){
                if(vector[i]<vector[j]){
                    int aux=vector[i];
                    vector[i]=vector[j];
                    vector[j]=aux;
                }
            }
        }
    }   
}