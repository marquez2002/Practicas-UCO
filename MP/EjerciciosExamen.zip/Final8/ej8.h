#ifndef __ej8__
#define __ej__
void rellenarVector(int* vector, int nEle);
void imprimirVector(int* vector, int nEle);
void ordenarVector(int* vector, int nEle, int criterio);
#endif