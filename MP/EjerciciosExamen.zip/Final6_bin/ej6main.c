#include "ej6.h"
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char const* argv[]){
    if(argc<4){
        printf("ERROR EN LA ESTRUCTURA\n");
        exit(0);
    }
    FILE* f1;
    FILE* f2;
    FILE* f3;
    if((f1=fopen(argv[1], "rb"))==NULL){
        printf("ERROR AL ABRIR EL ARCHIVO\n");
        exit(0);
    }
    if((f2=fopen(argv[2], "wb"))==NULL){
        printf("ERROR AL ABRIR EL ARCHIVO\n");
        exit(0);
    }
    if((f3=fopen(argv[3], "wb"))==NULL){
        printf("ERROR AL ABRIR EL ARCHIVO\n");
        exit(0);
    }
    fclose(f1);
    fclose(f2);
    fclose(f3);

    int x;
    printf("Valor de x=");
    scanf("%d", &x);
    generarArchivos(argv[1], argv[2], argv[3], x);
}
