#include "ej6.h"
#include <stdio.h>
#include <stdlib.h>

void generarArchivos(char const* archivo1, char const* archivo2, char const* archivo3, int x){
    FILE* f1;
    FILE* f2;
    FILE* f3;
    f1=fopen(archivo1, "rb");
    f2=fopen(archivo2, "wb");
    f3=fopen(archivo3, "wb");
    int nEle=(ftell(f1)/sizeof(struct producto));
    struct producto* aux;
    if((aux=(struct producto*)calloc(nEle, sizeof(struct producto)))==NULL){
        printf("ERROR\n");
        exit(0);
    }
    fread(aux, sizeof(struct producto), nEle, f1);
    for(int i=0; i<nEle; i++){
        if(aux[i].unidades>x){
            fprintf(f2, "%s %d %f %d\n", aux[i].nombre, aux[i].cod, aux[i].precio, aux[i].unidades);
        }
        else{
            fprintf(f3, "%s %d %f %d\n", aux[i].nombre, aux[i].cod, aux[i].precio, aux[i].unidades);
        }
    }
    fclose(f1);
    fclose(f2);
    fclose(f3);

}

