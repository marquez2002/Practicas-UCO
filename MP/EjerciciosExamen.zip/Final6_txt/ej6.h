#ifndef __ej6__
#define __ej6__
struct producto{
    char nombre[50];
    int cod;
    float precio;
    int unidades;
};
void generarArchivos(char const* archivo1, char const* archivo2, char const* archivo3, int x);
int contar(char const* archivo);
#endif