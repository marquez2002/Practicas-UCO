#include "ej6.h"
#include <stdio.h>
#include <stdlib.h>

void generarArchivos(char const* archivo1, char const* archivo2, char const* archivo3, int x){
    int nEle=contar(archivo1)+1;
    FILE* f1;
    FILE* f2;
    FILE* f3;
    f1=fopen(archivo1, "rb");
    f2=fopen(archivo2, "wb");
    f3=fopen(archivo3, "wb");
    char nombre[256];
    int cod, unidades;
    float precio;
    for(int i=0; i<(nEle); i++){
        fscanf(f1, "%s %d %f %d\n", nombre, &cod, &precio, &unidades);
        if(unidades>x){
            fprintf(f2, "%s %d %.2f %d\n", nombre, cod, precio, unidades);
        }
        else{
            fprintf(f3, "%s %d %.2f %d\n", nombre, cod, precio, unidades);
        }
    }
    fclose(f1);
    fclose(f2);
    fclose(f3);

}


int contar(char const* archivo){
    int contador=0;
    char aux[256];
    FILE* f;
    f=fopen(archivo, "r");
    if(fgets(aux, 256, f)!=NULL || feof(f)){
        while((fgets(aux, 256, f))!=NULL){
            contador++;
        }
    }
    return contador;
}
