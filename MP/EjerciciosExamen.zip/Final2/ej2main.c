#include "ej2.h"
#include <stdio.h>
#include <stdlib.h>

int main(){
    struct datos* Vector;
    int nEle=3;
    if((Vector=(struct datos*)calloc(nEle, sizeof(struct datos)))==NULL){
        printf("ERROR al reservar memoria\n");
        exit(0);
    }
    for(int i=0; i<nEle;i++){
        printf("Código: ");
        scanf("%d", &Vector[i].codigo);
        printf("Nombre: ");
        scanf("%s", Vector[i].nombre);
        printf("Peso (kg): ");
        scanf("%f", &Vector[i].peso);
        printf("Altura (m): ");
        scanf("%f", &Vector[i].altura);
    }

    int criterio;
    printf("Criterio 0. Ascendente por orden por IMC\nCriterio 1. Descendente por Nombre\nCriterio:");
    scanf("%d", &criterio);
    ejercicio1(nEle, Vector, criterio);
    printf_Vector(nEle, Vector);
}