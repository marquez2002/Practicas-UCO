#ifndef __ej2__
#define __ej2__
#define LENGTH 100
struct datos{
    int codigo;
    char nombre[LENGTH];
    float peso;
    float altura;
};

void ejercicio1(int nEle, struct datos* Vector, int criterio);
int Ascendente(const void* a, const void* b);
int Descendente(const void* a, const void* b);
void printf_Vector(int nEle, struct datos* Vector);
#endif