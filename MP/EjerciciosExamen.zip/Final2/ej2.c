#include "ej2.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void ejercicio1(int nEle, struct datos* Vector, int criterio){
    int (*funcion)(const void*, const void*);
    if(criterio==0){
        funcion=&Ascendente;
    }
    if(criterio==1){
        funcion=&Descendente;
    }
    qsort(Vector, nEle, sizeof(struct datos), funcion);
}

int Ascendente(const void* a, const void* b){
    float pesoA=(*(struct datos*)a).peso;
    float pesoB=(*(struct datos*)b).peso;

    float alturaA=(*(struct datos*)a).altura;
    float alturaB=(*(struct datos*)b).altura;

    float incA=(pesoA/(alturaA*alturaA));
    float incB=(pesoB/(alturaB*alturaB));

    float diferencia=incA-incB;

    if(diferencia<0){
        return -1;
    }

    if(diferencia==0){
        return 0;
    }

    if(diferencia>0){
        return 1;
    }
    return 0;
}

int Descendente(const void* a, const void* b){
    char* nombreA=(*(struct datos*)a).nombre;
    char* nombreB=(*(struct datos*)b).nombre;
    return(strcmp(nombreA, nombreB));

}

void printf_Vector(int nEle, struct datos* Vector){
    for(int i=0; i<nEle; i++){
        printf("%d %s %f %f\n", Vector[nEle].codigo, Vector[nEle].nombre, Vector[nEle].peso, Vector[nEle].altura);
    }
}