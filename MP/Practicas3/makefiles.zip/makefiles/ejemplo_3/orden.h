/* --------------------------------------
   Fichero: orden.h
   Contiene el prototipo de la funci�n
   de ordenaci�n (burbuja)
   -------------------------------------*/
#ifndef ORDEN
#define ORDEN

void ordena_vector(int * p, int tope);
void swap(int *a, int * b);
#endif
