# PRÁCTICAS PW - Gestión de Campamentos - GM1 Equipo 3

## Descripción
Las prácticas consistirán en hacer un proyecto acerca de la gestión de campamentos, donde se encarga de gestionar los asistentes, las actividades y los campamentos.

## Tabla de Contenido
- [Preparación](#preparación)
- [Uso](#uso)
- [Contenidos](#contenidos)
- [Créditos](#créditos)
- [Contacto](#contacto)

## Preparación
1. Simplemente tendrá que importar el sistema de archivos en eclipse y esperar que carge su contenido.

## Uso
- Tendrá que abrir el archivo main 
- Ejecutar con el boton Run Main y comenzar a interactuar con el programa.
- Crea, edita y elimina tareas fácilmente.

## Contenidos
- Clase Asistente con toda la información y métodos asociados.
- Clase Actividad con toda la información y métodos asociados.
- Clase Campamento con toda la información y métodos asociados.
- Clase Monitor con toda la información y métodos asociados.
- Clase Factory Inscripcion con toda la información y métodos asociados.
- Gestores de Asistentes, Campamentos e Inscripciones.
- Main, donde podrá interconectar todos los contenidos anteriormente para la gestion de campamentos.
- Utils, donde encontrará la creacion de los HashMap y los metodos para su lectura y escritura.

## Créditos
- Este proyecto fue realizado siguiente los puntos del documento "Introducción Al Proyecto de Prácticas" por los alumnos que aparecen en el siguiente apartado.

## Contacto
Puede contactarnos a traves de nuestros correos electrónicos:
Antonio Jiménez Jiménez - i02jijia@uco.es
Carlos Marín Rodríguez - i02maroc@uco.es
Gonzalo Márquez de Torres - i02matog@uco.es
José María Muñoz López - i02muloj@uco.es