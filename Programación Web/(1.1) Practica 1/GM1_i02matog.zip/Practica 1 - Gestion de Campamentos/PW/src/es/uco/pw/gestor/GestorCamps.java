package es.uco.pw.gestor;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

import es.uco.pw.activity.Activity;
import es.uco.pw.activity.Activity.LevelEducation;
import es.uco.pw.activity.Activity.Timetable;
import es.uco.pw.camp.Camp;
import es.uco.pw.monitor.Monitor;
import es.uco.pw.utils.FileUtils;

/**
 * Clase que representa el gestor de los campamentos dentro del sistema.
 * @author Antonio Jiménez Jiménez
 * @author Carlos Marín Rodríguez
 * @author Gonzalo Márquez de Torres
 * @author José María Muñoz López
 * @since 05-10-2023
 * @version 1.0
 */
 

public class GestorCamps {

	public static void main(Scanner myObj) throws ParseException, IOException {
		int opcion = 99;
		
		/**
		 * Se procede a leer los archivos de los monitores, actividades y campamentos
		 */
		FileUtils fileUtils = new FileUtils();
		HashMap<Integer, Monitor> monitorMap = fileUtils.getMonitorMap();
		HashMap<String, Activity> activityMap = fileUtils.getActivityMap();
		HashMap<Integer, Camp> campMap = fileUtils.getCampMap();
		
		/**
		 * Creamos un menu donde el usuario debe elegir entre los valores que aparecen en este
		 */
		while (opcion != 0) {
			System.out.println("Indique una opcion");
			System.out.println("1.- Crear monitor");
			System.out.println("2.- Crear actividad");
			System.out.println("3.- Crear campamento");
			System.out.println("4.- Asignar monitores a actividad");
			System.out.println("5.- Asignar actividades a campamento");
			System.out.println("6.- Asignar monitor responsable a campamento");
			System.out.println("7.- Asignar monitor de atencion especial a campamento");
			System.out.println("0.- Guardar y salir al menu superior");
			opcion = Integer.parseInt(myObj.nextLine());

			/**
			 * OPCION 1: Añadir un monitor
			 * Se introducen los datos del monitor que se pretende introducir.
			 * En caso de que no coincida con los datos de otro monitor se introduce en el sistema.
			 */
			switch (opcion) {
			case 1: {
				/**
                 * Para evitar que se repitan los IDs, se coge el ultimo creado y se incrementa 
                 */
				boolean existeUsu = false;
				int IdNuevo = 0;
				for (Map.Entry<Integer, Monitor> set : monitorMap.entrySet()) {
					if (set.getKey() > IdNuevo) {
						IdNuevo = set.getKey();
					}
				}
				IdNuevo = IdNuevo + 1;

				String nombreNuevo, apellidoNuevo;
				System.out.println("Indique nombre del nuevo monitor");
				nombreNuevo = myObj.nextLine();

				System.out.println("Indique apellido del nuevo monitor");
				apellidoNuevo = myObj.nextLine();

				boolean atencion = false;
				int atencion_especial = 10;
				while (atencion_especial < 1 || atencion_especial > 2) {
					System.out.println("Indique una opcion");
					System.out.println("1.- No es un monitor de educacion especial");
					System.out.println("2.- Es un monitor de educacion especial");
					atencion_especial = Integer.parseInt(myObj.nextLine());
				}

				if (atencion_especial == 2) {
					atencion = true;
				}

				Monitor monitor = new Monitor(IdNuevo, nombreNuevo, apellidoNuevo, atencion);

				if (monitorMap.size() != 0) {

					for (Map.Entry<Integer, Monitor> set : monitorMap.entrySet()) {
						Monitor m = set.getValue();
						System.out.println("--Buscando monitor");
						System.out.println(m.getName() + "---" + monitor.getName() + "---");
						if (nombreNuevo.equals(m.getName())) {
							if (apellidoNuevo.equals(m.getSurname())) {
								existeUsu = true;
								System.out.println("Este monitor ya existe");
							}
						}
					}

				}
				if (existeUsu == false) {
					monitorMap.put(IdNuevo, monitor);
				}
				break;
			}
			
			/**
			 * OPCION 2: Añadir una actividad
			 * Se introducen los datos de la actividad que se pretende introducir.
			 * En caso de que no coincida con los datos de otro monitor se introduce en el sistema.
			 */
			case 2: {
				System.out.println("Indique el nombre de la actividad");
				String name = myObj.nextLine();

				Activity activity = activityMap.get(name);

				if (activity == null) {
					int level_education_id = 0;
					while (level_education_id < 1 || level_education_id > 3) {
						System.out.println("Indique una opcion");
						System.out.println("1.- Infantil (4-6 años)");
						System.out.println("2.- Juvenil (7-12 años)");
						System.out.println("3.- Adolescente (13-17 años)");
						level_education_id = Integer.parseInt(myObj.nextLine());
					}

					LevelEducation levelEducation = LevelEducation.ADOLESCENTE;
					switch (level_education_id) {
						case 1: {
							levelEducation = LevelEducation.INFANTIL;
							break;
						}
						case 2: {
							levelEducation = LevelEducation.JUVENIL;
							break;
						}
					}

					int time_table_id = 0;
					while (time_table_id < 1 || time_table_id > 2) {
						System.out.println("Indique una opcion");
						System.out.println("1.- Mañana");
						System.out.println("2.- Tarde");
						time_table_id = Integer.parseInt(myObj.nextLine());
					}

					Timetable timeTable = Timetable.MANANA;
					if (time_table_id == 2) {
						timeTable = Timetable.TARDE;
					}

					System.out.println("Indique el numero maximo de asistentes");
					int maximumAsistent = Integer.parseInt(myObj.nextLine());

					System.out.println("Indique el numero de monitores necesarios para esta actividad");
					int numberMonitor = Integer.parseInt(myObj.nextLine());

					activity = new Activity(name, levelEducation, timeTable, maximumAsistent, numberMonitor);
					activityMap.put(name, activity);

				} else {
					System.out.println("Esta actividad ya esta registrada");
				}
				break;
			}
			
			/**
			 * OPCION 3: Añadir un campamento
			 * Se introducen los datos del campamento que se pretende introducir.
			 */
			case 3: {// Añadir campamento
				int IdNuevo = 0;
				/**
                 * Para evitar que se repitan los IDs, se coge el ultimo creado y se incrementa 
                 */
				for (Map.Entry<Integer, Camp> set : campMap.entrySet()) {
					if (set.getKey() > IdNuevo) {
						IdNuevo = set.getKey();
					}
				}
				IdNuevo = IdNuevo + 1;

				SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy");
				System.out.println("Indique la fecha de inicio del campamento (dd/mm/aaaa)");
				Date startDate, endDate = null;
				String fecha = myObj.nextLine();
				startDate = formato.parse(fecha);
				while (endDate == null) {
					System.out.println("Indique la fecha de fin del campamento (dd/mm/aaaa)");
					fecha = myObj.nextLine();
					endDate = formato.parse(fecha);
					/**
					 * Se comprueba que la fecha final no es anterior que la inicial
					 */
					if (endDate.before(startDate)) {
						endDate = null;
						System.out.println("La fecha de fin no puede ser anterior a la fecha de inicio");
					}
				}
				
				int level_education_id = 0;
				while (level_education_id < 1 || level_education_id > 3) {
					System.out.println("Indique una opcion");
					System.out.println("1.- Infantil (4-6 años)");
					System.out.println("2.- Juvenil (7-12 años)");
					System.out.println("3.- Adolescente (13-17 años)");
					level_education_id = Integer.parseInt(myObj.nextLine());
				}

				LevelEducation levelEducation = LevelEducation.ADOLESCENTE;
				switch (level_education_id) {
					case 1: {
						levelEducation = LevelEducation.INFANTIL;
						break;
					}
					case 2: {
						levelEducation = LevelEducation.JUVENIL;
						break;
					}
				}

				System.out.println("Indique el numero maximo de asistentes");
				int maximumAsistent = Integer.parseInt(myObj.nextLine());

				Camp camp = new Camp(IdNuevo, startDate, endDate, levelEducation, maximumAsistent);
				campMap.put(IdNuevo, camp);
				break;
			}
			
			/**
			 * OPCION 4: Asociar un monitor a una actividad
			 * Se introducen el nombre la actividad y se comprueba su existencia y si existe la posibilidad de introducirla.
			 * Posteriormente, se introduce el id del monitor y se comprueba su existencia.
			 */
			case 4: {
				Activity activity = null;
				boolean activity_available = false;
				while (activity == null) {
					System.out.println("Introduzca el nombre de la actividad que desea gestionar");
					for (Map.Entry<String, Activity> set : activityMap.entrySet()) {
						Activity a = set.getValue();
						/**
						 * Se comprubea si existe la posibilidad de inscribir un monitor mas a la actividad
						 */
						if (a.getMonitorList().size() < a.getNumberMonitor()) {
							System.out.println("-----");
							System.out.println(a.toString());
							System.out.println("-----");
							activity_available = true;
						}

					}

					if (activity_available) {
						activity = activityMap.get(myObj.nextLine());
						if (activity == null) {
							System.out.println("El nombre introducido no corresponde con ninguna actividad.");
						} else {
							Monitor monitor = null;
							while (monitor == null) {
								System.out.println("Introduzca el id del monitor al que desea asociar con la actividad seleccionada");
								for (Map.Entry<Integer, Monitor> set : monitorMap.entrySet()) {
									Monitor m = set.getValue();
									System.out.println("-----");
									System.out.println(m.toString());
									System.out.println("-----");

								}
								monitor = monitorMap.get(Integer.parseInt(myObj.nextLine()));
								if (monitor == null) {
									System.out.println("El id introducido no corresponde con ningun monitor.");
								}
							}

							if (activity.asociarMonitor(monitor)) {
								activityMap.put(activity.getName(), activity);
							}
						}
					} else {
						System.out.println("Todas las actividades tienen asignados el maximo de monitores permitidos.");
						break;
					}
				}

				break;
			}
			
			/**
			 * OPCION 5: Asociar una actividad a un campamento
			 * Se introducen el id del campamento y se comprueba su existencia.
			 * Se introduce la actividad a traves del nombre, comprobando su existencia y su nivel educativo.
			 */
			case 5: {
				Camp camp = null;
				boolean camps_available = false;
				while (camp == null) {
					System.out.println("Introduzca el id del campamentos que desea gestionar");
					for (Map.Entry<Integer, Camp> set : campMap.entrySet()) {
						Camp c = set.getValue();
						System.out.println("-----");
						System.out.println(c.toString());
						System.out.println("-----");
						camps_available = true;

					}

					if (camps_available) {
						camp = campMap.get(Integer.parseInt(myObj.nextLine()));
						if (camp == null) {
							System.out.println("El id introducido no corresponde con ningun campamento.");
						} else {
							Activity activity = null;
							boolean activity_available = false;
							while (activity == null) {

								for (Map.Entry<String, Activity> set : activityMap.entrySet()) {
									Activity a = set.getValue();
									if (a.getLevelEducation() == camp.getLevelEducation()) {
										System.out.println("-----");
										System.out.println(a.toString());
										System.out.println("-----");
										activity_available = true;
									}
								}

								if (activity_available) {
									System.out.println("Introduzca el nombre de la actividad que desea asociar con el campamento seleccionado");
									activity = activityMap.get(myObj.nextLine());
									if (activity == null) {
										System.out
												.println("La nombre introducido no corresponde con ninguna actividad.");
									} else {
										if (camp.asociarActividad(activity)) {
											campMap.put(camp.getID(), camp);
										}
									}
								} else {
									System.out.println("No hay actividades disponibles del mismo nivel educacional que el campamento.");
									break;
								}
							}
						}
					} else {
						System.out.println("No hay campamentos aun, asegurese de crearlos antes.");
						break;
					}
				}
				break;
			}
			
			/**
			 * OPCION 5: Asignar monitor responsable a un campamento
			 * Se introduce el id del campamento y se comprueba su existencia y si hay algun monitor asignado  
			 * Se introducen el id del monitor asignado a ese campamento y se comprueba si ha sido asignado ya.
			 *  
			 */
			case 6: {
				Camp camp = null;
				boolean camps_available = false;
				while (camp == null) {
					System.out.println("Introduzca el id del campamentos que desea gestionar");
					for (Map.Entry<Integer, Camp> set : campMap.entrySet()) {
						Camp c = set.getValue();
						System.out.println("-----");
						System.out.println(c.toString());
						System.out.println("-----");
						camps_available = true;

					}

					if (camps_available) {
						camp = campMap.get(Integer.parseInt(myObj.nextLine()));
						if (camp == null) {
							System.out.println("El id introducido no corresponde con ningun campamento.");
						} else {
							Monitor monitor = null;
							boolean monitors_available = false;
							while (monitor == null) {
								for (Activity a : camp.getActivityList()) {
									System.out.println("-----");
									System.out.println("Actividad: " + a.getName());

									for (Monitor m : a.getMonitorList()) {
										System.out.println("-----");
										System.out.println("Monitor: " + m.toString());
										System.out.println("-----");
										monitors_available = true;
									}
									System.out.println("-----");
								}
								if (monitors_available) {
									System.out.println("Introduzca el id del monitor de los que participan en campamento que sera asignado como monitor responsable");
									monitor = monitorMap.get(Integer.parseInt(myObj.nextLine()));
									if (monitor == null) {
										System.out.println("El id introducido no corresponde con ningun monitor.");
									} else {
										if (camp.asociarMonitor(monitor)) {
											campMap.put(camp.getID(), camp);
										}
									}
								} else {
									System.out.println(
											"No hay monitores disponibles en este campamento, asegurese antes de asociar actividades al campamento y monitores a estas.");
									break;
								}
							}
						}
					} else {
						System.out.println("No hay campamentos aun, asegurese de crearlos antes.");
						break;
					}
				}
				break;
			}
			
			/**
			 * OPCION 7: Asociar un monitor de atencion especial a un campamento.
			 * Se comprueba si hay creado un campamento con necesidad de un monitor de atencion especial o si hay creado un monitor de atencion especial.
			 * Se introducen el id del campamento y se comprueba su existencia y si es necesario un monitor de atencion especial.
			 * Se introduce el id del monitor y se asocia al mismo.
			 */
			case 7: {
				Camp camp = null;
				boolean camps_available = false;
				while (camp == null) {
					System.out.println("Introduzca el id del campamentos que desea gestionar");
					for (Map.Entry<Integer, Camp> set : campMap.entrySet()) {
						Camp c = set.getValue();
						if (c.getNeededSpecialMonitor()) {
							System.out.println("-----");
							System.out.println(c.toString());
							System.out.println("-----");
							camps_available = true;
						}

					}
					if (camps_available) {
						camp = campMap.get(Integer.parseInt(myObj.nextLine()));
						if (camp == null) {
							System.out.println("El id introducido no corresponde con ningun campamento.");
						} else if (!camp.getNeededSpecialMonitor()) {
							System.out.println("El campamento introducido no necesita monitor de educacion especial.");
							camp = null;
						} else {
							Monitor monitor = null;
							boolean monitors_available = false;
							while (monitor == null) {
								for (Map.Entry<Integer, Monitor> set : monitorMap.entrySet()) {
									Monitor m = set.getValue();
									if (m.getEspecial()) {
										System.out.println("-----");
										System.out.println(m.toString());
										System.out.println("-----");
										monitors_available = true;
									}
								}
								if (monitors_available) {
									System.out.println("Introduzca el id del monitor de atencion especial que desea asociar con este campamento");
									monitor = monitorMap.get(Integer.parseInt(myObj.nextLine()));
									if (monitor == null) {
										System.out.println("El id introducido no corresponde con ningun monitor.");
									} else {
										if (camp.asociarMonitorEspecial(monitor)) {
											campMap.put(camp.getID(), camp);
										}
									}
								} else {
									System.out.println("No hay monitores de atencion especial disponibles, asegurese de crearlos antes.");
									break;
								}
							}
						}
					} else {
						System.out.println("No hay campamentos que necesiten de atencion especial disponibles, asegurese de crearlos antes.");
						break;
					}
				}
				break;
			}
			}
		}
		
		/**
		 * Cuando finalizan las operaciones, se guardan todos los datos.
		 */
		fileUtils.setMonitorMap(monitorMap);
		fileUtils.setActivityMap(activityMap);
		fileUtils.setCampMap(campMap);
		fileUtils.saveFiles();
	}
}
