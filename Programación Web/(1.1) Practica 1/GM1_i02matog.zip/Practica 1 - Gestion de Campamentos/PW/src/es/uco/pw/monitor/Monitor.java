package es.uco.pw.monitor;

/**
 * Clase que representa un monitor dentro del sistema.
 * @author Antonio Jiménez Jiménez
 * @author Carlos Marín Rodríguez
 * @author Gonzalo Márquez de Torres
 * @author José María Muñoz López
 * @since 28-09-2023
 * @version 1.0
 */

public class Monitor {
	
	/**
	 * Identificador del monitor 
	 */
	private int id;
	
	/**
	 * Nombre del monitor 
	 */
	private String name;
	
	/**
	 * Apellido del monitor 
	 */
	private String surname;
	
	/**
	 * Muestra si el monitor es un educador especial 
	 */
	private boolean especial;
	 
	 
	/**
	* Constructor vacio de la clase monitor
	* @param none
	* @return none
	*/
	 
	public Monitor(){	
		
	}
	 
	/**
	 * Constructor de la clase monitor
	 * @param id El identificador del monitor
	 * @param name El nombre del monitor
	 * @param surname El apellido del monitor
	 * @param especial El monitor es un educador especial
	 * @return none
	*/
	 
	public Monitor(int id, String name, String surname, boolean especial){
		this.id=id;
		this.name=name;
		this.surname=surname;
		this.especial=especial;
	}
	 
	/**
	* Devuelve el identificador del monitor
	* @param none
	* @return id El identificador del monitor
	*/

	public int getId(){
		return id;
	}
	
	/**
	* Modifica el identificador del monitor
	* @param id El identificador del monitor
	* @return none
	*/
	 
	public void setId(int id) {
		this.id=id;
	}
	
	/**
	* Devuelve el nombre del monitor
	* @param none
	* @return name El nombre del monitor
	*/
	 
	public String getName() {
		return name;	
	}
	
	/**
	* Modifica el nombre del monitor
	* @param name El nombre del monitor
	* @return none
	*/
	 
	public void setName(String name){
		this.name=name;
	}
	
	
	/**
	* Modifica el apellido del monitor
	* @param surname El apellido del monitor
	* @return none
	*/
	
	 
	public void setSurname(String surname){
		this.surname=surname;
	}
	
	/**
	* Devuelve el apellido del monitor
	* @param none
	* @return surname El apellido del monitor
	*/
	
	public String getSurname() {
		return surname;	
	}
	
	/**
	* Devuelve si el monitor es un educador especial
	* @param none
	* @return especial El monitor es un educador especial
	*/
	
	
	public boolean getEspecial() {
		return especial;
	}
	
	/**
	* Modifica si el monitor es un educador especial
	* @param especial El monitor es un educador especial
	* @return none
	*/
 
	public void setEspecial(boolean especial){
		this.especial=especial;
	}
	
	 
	/*
	* Muestra la informacion referente a un monitor
	* @param none
	* @return monitorInfo La informacion de un monitor
	*/
	
	@Override
	public String toString() {
		String monitorInfo="El ID del monitor es "+this.id+" ,con nombre "+this.name+" "+this.surname+".";
		if(especial == true){
			monitorInfo +=" Es elegible para atender a asistentes con atención especial.";
		}
		else {
			monitorInfo +=" No es elegible para atender a asistentes con atención especial.";
		}
		return monitorInfo;
	}
}
