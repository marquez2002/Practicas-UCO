package es.uco.pw.inscription;

import java.util.Date;

/**
 * Clase que representa la inscripcion tardia de una reserva extendida a la InscriptionFactory dentro del sistema.
 * @author Antonio Jiménez Jiménez
 * @author Carlos Marín Rodríguez
 * @author Gonzalo Márquez de Torres
 * @author José María Muñoz López
 * @since 10-10-2023
 * @version 1.0
 */

public class InscriptionTardia extends Inscription {
	
	/**
	 * Constructor de la clase inscription tardia
	 * @return none
	*/
	
	public InscriptionTardia(){
		this.timeInscription=TimeInscription.TARDIA;
	}

	/**
	 * Constructor de la clase inscription tardia
	 * @param idAsistent El identificador del asistente
	 * @param idCamp El identificador del campamento
	 * @param price El precio de la inscripcion
	 * @param typeInscription El tipo de la inscripcion
	 * @return none
	*/
	public InscriptionTardia(int idAsistent, int idCamp, Date date, float price, TypeInscription typeInscription){
		this.idAsistent=idAsistent;
		this.idCamp=idCamp;
		this.price=price;
		this.typeInscription= typeInscription;
		this.inscriptionDate=date;
		this.timeInscription=TimeInscription.TARDIA;
	}
	
	/*
	* Muestra la informacion referente a una inscripcion tardia
	* @param none
	* @return inscripctionInfo La informacion de la inscripcion
	*/
	@Override
	public String toString() {
		return super.toString() + " La inscripción es de tipo tardia.";
	}
	
	/*
	* Indica si se permite la cancelacion
	* @param none
	* @return false La inscripcion no se puede cancelar
	*/
	
	@Override
	public boolean allowCancellation() {
		return false;
	}
}