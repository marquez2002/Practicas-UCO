package es.uco.pw.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Scanner;

import es.uco.pw.activity.Activity;
import es.uco.pw.activity.Activity.LevelEducation;
import es.uco.pw.activity.Activity.Timetable;
import es.uco.pw.asistent.Asistent;
import es.uco.pw.camp.Camp;
import es.uco.pw.inscription.Inscription;
import es.uco.pw.inscription.InscriptionFactory;
import es.uco.pw.inscription.Inscription.TimeInscription;
import es.uco.pw.inscription.Inscription.TypeInscription;
import es.uco.pw.monitor.Monitor;

/**
 * Clase para trabajar con los ficheros.
 * @author Antonio Jiménez Jiménez
 * @author Carlos Marín Rodríguez
 * @author Gonzalo Márquez de Torres
 * @author José María Muñoz López
 * @since 10-10-2023
 * @version 1.0
 */

public class FileUtils {
	
	/**
	 * Creacion de los HashMap con los que vamos a trabajar en la practica
	 */
	private HashMap<Integer, Asistent> asistentMap = new HashMap<Integer,Asistent>();
	private HashMap<Integer, Monitor> monitorMap = new HashMap<Integer,Monitor>();
	private HashMap<Integer, Camp> campMap = new HashMap<Integer,Camp>();
	private HashMap<String, Activity> activityMap = new HashMap<String,Activity>();
	private ArrayList<Inscription> inscriptionList = new ArrayList<Inscription>(1);
	
	/**
	 * Metodos gets que utilizaremos para retronar los diferentes mapas  
	 */
	
	public HashMap<Integer, Asistent> getAsistentMap() {
		return asistentMap;
	}
	public void setAsistentMap(HashMap<Integer, Asistent> asistentMap) {
		this.asistentMap = asistentMap;
	}
	public HashMap<Integer, Monitor> getMonitorMap() {
		return monitorMap;
	}
	public void setMonitorMap(HashMap<Integer, Monitor> monitorMap) {
		this.monitorMap = monitorMap;
	}
	public HashMap<Integer, Camp> getCampMap() {
		return campMap;
	}
	public void setCampMap(HashMap<Integer, Camp> campMap) {
		this.campMap = campMap;
	}
	public HashMap<String, Activity> getActivityMap() {
		return activityMap;
	}
	public void setActivityMap(HashMap<String, Activity> activityMap) {
		this.activityMap = activityMap;
	}
	public ArrayList<Inscription> getInscriptionList() {
		return inscriptionList;
	}
	public void setInscriptionList(ArrayList<Inscription> inscriptionList) {
		this.inscriptionList = inscriptionList;
	}
	
	
	public FileUtils() throws ParseException, IOException {	
		
		Properties properties= new Properties();
	    properties.load(new FileInputStream(new File("configuracion.properties")));
		
		/**
		 * Metodo para la lectura del fichero de asistentes  
		 */
		File file = new File(properties.getProperty("asistent_file"));
		if(!file.exists()){
			file.createNewFile();
		}
		Scanner myReader = new Scanner(file);
		while(myReader.hasNextLine()) {
			int idValue = Integer.parseInt(myReader.nextLine());
			String nameValue = myReader.nextLine();
			String surnameValue = myReader.nextLine();
			String fechaNF=myReader.nextLine();
			SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy");
			Date dateValue = formato.parse(fechaNF);
			boolean especialValue = Boolean.parseBoolean(myReader.nextLine());
			Asistent asistent =new Asistent(idValue, nameValue, surnameValue, dateValue, especialValue);
			asistentMap.put(idValue, asistent);
		}
		myReader.close();
		
		/**
		 * Metodo para la lectura del fichero de monitores  
		 */
		file = new File(properties.getProperty("monitor_file"));
		if(!file.exists()){
			file.createNewFile();
		}
		myReader = new Scanner(file);
		while(myReader.hasNextLine()) {
			int idValue = Integer.parseInt(myReader.nextLine());
			String nameValue = myReader.nextLine();
			String surnameValue = myReader.nextLine();
			boolean especialValue = Boolean.parseBoolean(myReader.nextLine());
			Monitor monitor =new Monitor(idValue, nameValue, surnameValue, especialValue);
			monitorMap.put(idValue, monitor);
		}
		myReader.close();
		
		/**
		 * Metodo para la lectura del fichero de actividades  
		 */
		file = new File(properties.getProperty("activities_file"));
		if(!file.exists()){
			file.createNewFile();
		}
		myReader = new Scanner(file);
		while(myReader.hasNextLine()) {
			String name= myReader.nextLine();
			LevelEducation levelEducation = LevelEducation.valueOf(myReader.nextLine());
			Timetable timetable = Timetable.valueOf(myReader.nextLine());
			int maximumAsistent = Integer.parseInt(myReader.nextLine());
			int numberMonitor = Integer.parseInt(myReader.nextLine());
			Activity activity =new Activity(name, levelEducation, timetable, maximumAsistent, numberMonitor);
			String monitors = myReader.nextLine();
			if(!monitors.isEmpty()) {
				String[] monitor_ids = monitors.split(",");
				for (String monitor_id : monitor_ids) {
					activity.asociarMonitor(monitorMap.get(Integer.parseInt(monitor_id)));
				}					
			}
			activityMap.put(name, activity);
		}
		myReader.close();
		
		/**
		 * Metodo para la lectura del fichero de campamentos  
		 */
		file = new File(properties.getProperty("camps_file"));
		if(!file.exists()){
			file.createNewFile();
		}
		myReader = new Scanner(file);
		while(myReader.hasNextLine()) {
			int idValue = Integer.parseInt(myReader.nextLine());
			SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy");
			String startDateString=myReader.nextLine();
			Date startDate = formato.parse(startDateString);
			String endDateString=myReader.nextLine();
			Date endDate = formato.parse(endDateString);
			LevelEducation levelEducation = LevelEducation.valueOf(myReader.nextLine());
			int maximumAsistent = Integer.parseInt(myReader.nextLine());
			Camp camp =new Camp(idValue, startDate, endDate, levelEducation, maximumAsistent);
			String activities = myReader.nextLine();
			if(!activities.isEmpty()) {
				String[] activity_names = activities.split(",");
				for (String activity_name : activity_names) {
					camp.asociarActividad(activityMap.get(activity_name));
				}
			}
			String monitor_id = myReader.nextLine();
			if(!monitor_id.isEmpty()) {
				camp.asociarMonitor(monitorMap.get(Integer.parseInt(monitor_id)));					
			}
			camp.setNeedSpecialMonitor(Boolean.parseBoolean(myReader.nextLine()));
			String monitor_especial_id = myReader.nextLine();
			if(!monitor_especial_id.isEmpty()) {
				camp.asociarMonitorEspecial(monitorMap.get(Integer.parseInt(monitor_especial_id)));					
			}
			
			campMap.put(idValue, camp);
		}
		myReader.close();
		
		/**
		 * Metodo para la lectura del fichero de inscripciones  
		 */
		File myFile = new File(properties.getProperty("inscription_file"));
		if(!myFile.exists()){
			myFile.createNewFile();
		}
		myReader = new Scanner(myFile);
		while(myReader.hasNextLine()) {
			int idAsistent = Integer.parseInt(myReader.nextLine());
			Asistent asistent = asistentMap.get(idAsistent);
			int idCamp = Integer.parseInt(myReader.nextLine());
			Camp camp = campMap.get(idCamp);
			String fechaI=myReader.nextLine();
			SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy");
			Date inscriptionDate = formato.parse(fechaI);
			float price = Float.parseFloat(myReader.nextLine());
			TimeInscription timeInscription = TimeInscription.valueOf(myReader.nextLine());
			TypeInscription typeInscription = TypeInscription.valueOf(myReader.nextLine());
			Inscription inscription = InscriptionFactory.createInscription(asistent, camp, inscriptionDate, price, typeInscription, timeInscription);
			inscriptionList.add(inscription);
			
		}
		myReader.close();
	}
	
	public void saveFiles() throws IOException {
		Properties properties= new Properties();
	    properties.load(new FileInputStream(new File("configuracion.properties")));
		
	    /**
		 * Metodo para la escritura del fichero de asistentes  
		 */		
		FileWriter myWriter = new FileWriter(properties.getProperty("asistent_file"));
		for (Map.Entry<Integer, Asistent> set : asistentMap.entrySet()) {
			Asistent a = set.getValue();
            myWriter.write( a.getID()+"\n" );
			myWriter.write( a.getName()+"\n" );
			myWriter.write( a.getSurname()+"\n" );
			String pattern = "dd/MM/yyyy";
			SimpleDateFormat df = new SimpleDateFormat(pattern);
            String nacimiento = df.format(a.getDate());
            myWriter.write( nacimiento+"\n" );
            myWriter.write( a.getEspecial()+"\n" );
            
		}
		myWriter.close();
		
		/**
		 * Metodo para la lectura del fichero de monitores  
		 */
		myWriter = new FileWriter(properties.getProperty("monitor_file"));
		for (Map.Entry<Integer, Monitor> set : monitorMap.entrySet()) {
			Monitor m = set.getValue();
            myWriter.write( m.getId()+"\n" );
			myWriter.write( m.getName()+"\n" );
			myWriter.write( m.getSurname()+"\n" );
            myWriter.write( m.getEspecial()+"\n" );
            
		}
		myWriter.close();
		
		/**
		 * Metodo para la lectura del fichero de actividades  
		 */
		myWriter = new FileWriter(properties.getProperty("activities_file"));
		for (Map.Entry<String, Activity> set : activityMap.entrySet()) {
			Activity a = set.getValue();
			myWriter.write( a.getName()+"\n" );
			myWriter.write( a.getLevelEducation()+"\n" );
            myWriter.write( a.getTimetable()+"\n" );
            myWriter.write( a.getMaximumAsistent()+"\n" );
            myWriter.write( a.getNumberMonitor()+"\n" );
            List<String> monitor_list_ids = new ArrayList<String>(1);
            for(Monitor m : a.getMonitorList()){
            	monitor_list_ids.add(String.valueOf(m.getId()));
            }
            myWriter.write( String.join(",", monitor_list_ids)+"\n" );
            
		}
		myWriter.close();
		
		/**
		 * Metodo para la lectura del fichero de campamentos  
		 */
		myWriter = new FileWriter(properties.getProperty("camps_file"));
		for (Map.Entry<Integer, Camp> set : campMap.entrySet()) {
			Camp c = set.getValue();
            myWriter.write( c.getID()+"\n" );
            SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy");
            myWriter.write( df.format(c.getStartDate())+"\n" );
            myWriter.write( df.format(c.getEndDate())+"\n" );
            myWriter.write( c.getLevelEducation()+"\n" );
			myWriter.write( c.getMaximunAsistent()+"\n" );
			List<String> activity_list_ids = new ArrayList<String>(1);
            for(Activity a : c.getActivityList()){
            	activity_list_ids.add(a.getName());
            }
            myWriter.write( String.join(",", activity_list_ids)+"\n" );
            String monitor_responsable_id = "", monitor_especial_id = "";
            Monitor monitor = c.getMonitorResponsable();
            if(monitor != null) {
            	monitor_responsable_id = String.valueOf(monitor.getId());
            }
            myWriter.write( monitor_responsable_id+"\n" );
            myWriter.write( c.getNeededSpecialMonitor()+"\n" );
            Monitor monitor_especial = c.getMonitorEspecial();
            if(monitor_especial != null) {
            	monitor_especial_id = String.valueOf(monitor_especial.getId());
            }
            myWriter.write( monitor_especial_id+"\n" );
            
		}
		myWriter.close();
		
		/**
		 * Metodo para la lectura del fichero de inscripciones  
		 */
		myWriter = new FileWriter(properties.getProperty("inscription_file"));
		for(Inscription i:inscriptionList){
            myWriter.write( i.getIdAsistent()+"\n" );
			myWriter.write( i.getIdCamp()+"\n" );
			String pattern = "dd/MM/yyyy";
			SimpleDateFormat inscriptionDate = new SimpleDateFormat(pattern);
            myWriter.write( inscriptionDate.format(i.getInscriptionDate())+"\n" );
            myWriter.write( i.getPrice()+"\n" );
            myWriter.write(i.getTimeInscription()+"\n");
            myWriter.write(i.getTypeInscription()+"\n");
		}
		myWriter.close();
	}
}
