package es.uco.pw.camp;

import es.uco.pw.activity.*;
import es.uco.pw.activity.Activity.LevelEducation;
import es.uco.pw.monitor.*;

import java.text.SimpleDateFormat;
import java.util.*;

/**
 * Clase que representa un campamento dentro del sistema.
 * @author Antonio Jiménez Jiménez
 * @author Carlos Marín Rodríguez
 * @author Gonzalo Márquez de Torres
 * @author José María Muñoz López
 * @since 30-09-2023
 * @version 1.0
 */

public class Camp {
	
	/**
	 * Identificador del campamento
	 */
	private int id;
	
	/**
	 * Fecha de comienzo del campamento
	 */
	private Date startDate;
	
	/**
	 * Fecha de finalizacion del campamento
	 */
	private Date endDate;
	
	/**
	 * Nivel educativo que debe de tener para realizar un campamento
	 */
	private LevelEducation levelEducation;
	
	/**
	 * Numero maximo de asistente para realizar un campamento
	 */
	private int maximunAsistent;
	
	/**
	 * Lista para las actividades dentro de una actividad
	 */
	private List<Activity> activityList;
	
	/**
	 * Monitor responsable de un determinado campamento
	 */
	private Monitor monitorResponsable = null;
	
	/**
	 * Indica si el campamento necesita o no monitor especial
	 */
	private boolean neededSpecialMonitor = false;
	
	/**
	 * Monitor especial de un determinado campamento
	 */
	private Monitor monitorEspecial = null;
	 
	 
	/**
	* Constructor vacio de la clase campamento
	* @param none
	* @return none
	*/
	 
	public Camp(){	
	}
	 
	/**
	 * Constructor de la clase campamento
	 * @param id El identificador del campamento
	 * @param startDate La fecha de inicio del campamento
	 * @param endDate La fecha de final del campamento
	 * @param levelEducation El nivel educativo del campamento
	 * @param maximumAsistent El maximo numero de asistentes del campamento
	 * @return none
	*/
	 
	public Camp(int id, Date startDate, Date endDate, LevelEducation levelEducation, int maximunAsistent){
		this.id=id;
		this.startDate=startDate;
		this.endDate=endDate;
		this.levelEducation=levelEducation;
		this.maximunAsistent=maximunAsistent;
		activityList = new ArrayList<>();
	}
	 
	/**
	* Devuelve el identificador del campamento
	* @param none
	* @return name El identificador del campamento
	*/
	
	public int getID(){
		return id;
	}
	
	/**
	* Modifica el identificador del campamento
	* @param id El identificador del campamento
	* @return none
	*/
	 
	public void setID(int id) {
		this.id=id;
	}
	
	/**
	* Devuelve la fecha de inicio del campamento
	* @param none
	* @return startDate La fecha de inicio del campamento
	*/
	 
	public Date getStartDate() {
		return startDate;	
	}
	
	/**
	* Modifica la fecha de inicio del campamento
	* @param startDate La fecha de inicio del campamento
	* @return none
	*/
	
	public void setStartDate(Date startDate){
		this.startDate=startDate;
	}
	
	/**
	* Devuelve la fecha de final del campamento
	* @param none
	* @return endDate La fecha de final del campamento
	*/
	
	public Date getEndDate() {
		return endDate;	
	}
	
	/**
	* Modifica la fecha de final del campamento
	* @param endDate La fecha de final del campamento
	* @return none
	*/
	
	public void setEndDate(Date endDate){
		this.endDate=endDate;
	}
	
	/**
	* Devuelve el nivel educativo del campamento
	* @param none
	* @return levelEducation El nivel educativo del campamento
	*/
	
	public LevelEducation getLevelEducation() {
		return levelEducation;
	}
	
	/**
	* Modifica el nivel educacional del campamento
	* @param levelEducation El nivel educacional del campamento
	* @return none
	*/
 
	public void setLevelEducation(LevelEducation levelEducation){
		this.levelEducation=levelEducation;
	}
	
	/**
	* Devuelve el numero maximo de asistentes del campamento
	* @param none
	* @return maximumAsistent El maximo numero de asistentes del campamento
	*/
	
	public int getMaximunAsistent(){
		return maximunAsistent;
	}
	
	/**
	* Modifica el numero maximo de asistentes del campamento
	* @param maximunAsistent El numero maximo de asistentes del campametno
	* @return none
	*/
	 
	public void setMaximunAsistent(int maximunAsistent) {
		this.maximunAsistent=maximunAsistent;
	}
	
	
	/**
	* Devuelve la lista de actividades asociadas al campamento
	* @param none
	* @return activityList La lista de actividades asociadas al campamento
	*/
	
	public List<Activity> getActivityList() {
		return activityList;
	}

	/**
	* Modifica la lista de actividades asociadas al campamento
	* @param activityList La lista de actividades asociadas al campamento
	* @return none
	*/
	
	public void setActivityList(List<Activity> activityList) {
		this.activityList = activityList;
	}
	
	/**
	* Devuelve el monitor responsable asociado al campamento
	* @param none
	* @return monitorResponsable El monitor responsable asociado al campamento
	*/

	public Monitor getMonitorResponsable() {
		return monitorResponsable;
	}
	
	/**
	* Modifica el monitor responsable asociado al campamento
	* @param monitorResponsable El monitor responsable asociado al campamento
	* @return none
	*/

	public void setMonitorResponsable(Monitor monitorResponsable) {
		this.monitorResponsable = monitorResponsable;
	}
	
	
	/**
	* Devuelve un booleano indicando si se necesita un monitor especial
	* @param none
	* @return neededSpecialMonitor Un booleano indicando si se necesita un monitor especial
	*/
	
	public boolean getNeededSpecialMonitor() {
		return neededSpecialMonitor;
	}

	/**
	* Modifica el booleano indicando si se necesita un monitor especial
	* @param neededSpecialMonitor El booleano indicando si se necesita un monitor especial
	* @return none
	*/
	
	public void setNeedSpecialMonitor(boolean neededSpecialMonitor) {
		this.neededSpecialMonitor = neededSpecialMonitor;
	}

	/**
	* Devuelve el monitor especial asociado al campamento
	* @param none
	* @return monitorEspecial El monitor especial asociado al campamento
	*/

	public Monitor getMonitorEspecial() {
		return monitorEspecial;
	}
	
	/**
	* Modifica el monitor especial asociado al campamento
	* @param monitorEspecial El monitor especial asociado al campamento
	* @return none
	*/

	public void setMonitorEspecial(Monitor monitorEspecial) {
		this.monitorEspecial = monitorEspecial;
	}

	/*
	* Muestra la informacion referente a una campamento
	* @param none
	* @return campInfo La informacion de la campamento
	*/
	@Override
	public String toString() {
		SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy");
        String startDateString = formato.format(getStartDate());
        String endDateString = formato.format(getEndDate());
		String campInfo="El ID del campamento es "+this.id+", que inicia "+startDateString+" y finaliza "+endDateString+". El nivel educativo es "+this.levelEducation+" y el núumero máximo de asistentes es de "+this.maximunAsistent+". La lista de actividades será "+this.activityList+".";
		
		if(this.monitorResponsable!= null){
			campInfo +=" El monitor responsable es" + this.monitorResponsable + ".";
		}
		else {
			campInfo +=" Este campamento no tiene monitor responsable aun.";
		}
		
		if(this.monitorEspecial != null){
			campInfo +=" El monitor especial es" + this.monitorEspecial + ".";
		}
		else {
			campInfo +=" Este campamento no tiene monitor especial.";
		}
		
		return campInfo;
	}
	
	/*
	* Asocia una actividad de la lista de activdiades al campamento siempre que cumpla el nivel educativo
	* @param Actividad Una actividad de la lista de actividades
	* @return boolean La actividad ha sido asociada al campamento
	*/
	
	public boolean asociarActividad(Activity activity){
		if(activity.getLevelEducation().equals(getLevelEducation())){
			for (Activity a : activityList) {
				if(a.getName() == activity.getName()) {
					System.out.println("La actividad ya esta asociada al campamento.");
					return false;
				}
			}
			activityList.add(activity);
			return true;
		}
		else {
			System.out.println("La actividad no se puede asocair al campamento, puesto que no es del mismo nivel.");
			return false;
		}
	}
	
	/*
	* Asocia una monitor de la lista de monitores como monitor responsable
	* @param monitor Un monitor de la lista de monitores
	* @return boolean El monitor ha sido asociado al campamento como responsable
	*/
	 
	public boolean asociarMonitor(Monitor monitor){
		for (Activity activity : activityList) {
			for (Monitor monitorActivity: activity.getMonitorList()) {
				if(monitor.getId() == monitorActivity.getId()) {
					this.monitorResponsable=monitor;
					return true;
				}				
			}
		}
		
		System.out.println("El monitor no se puede asociar al campamento porque no pertenece a niguna actividad de este.");
		return false;
		
	}
	
	/*
	* Asocia una monitor de la lista de monitores como monitor especial
	* @param monitor Un monitor de la lista de monitores
	* @return boolean El monitor ha sido asociado al campamento como monitor especial
	*/ 
	public boolean asociarMonitorEspecial(Monitor monitor){
		if(!monitor.getEspecial()) {
			System.out.println("El monitor no se puede asociar al campamento como refuerzo especial porque no es de educación especial.");
			return false;
		}
		for (Activity activity : activityList) {
			for (Monitor monitorActivity: activity.getMonitorList()) {
				if(monitor.getId() == monitorActivity.getId()) {
					System.out.println("El monitor no se puede asociar al campamento como refuerzo especial porque ya pertenece a la actividad " + activity.getName() + " asociada a este.");
					return false;
				}				
			}
		}
		
		this.monitorEspecial=monitor;
		return true;
	}
}
