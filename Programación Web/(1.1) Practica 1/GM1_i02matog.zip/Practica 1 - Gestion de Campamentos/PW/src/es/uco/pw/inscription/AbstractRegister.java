package es.uco.pw.inscription;

/**
 * Clase abstracta que representa el tipo de inscripcion dentro del sistema.
 * @author Antonio Jiménez Jiménez
 * @author Carlos Marín Rodríguez
 * @author Gonzalo Márquez de Torres
 * @author José María Muñoz López
 * @since 04-10-2023
 * @version 1.0
 */

public abstract class AbstractRegister{
	
	/**
	 * El tipo de inscripcion que va a realizar
	 */
	protected int type;
}
