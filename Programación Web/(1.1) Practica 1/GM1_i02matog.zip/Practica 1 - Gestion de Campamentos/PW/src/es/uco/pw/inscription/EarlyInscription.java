package es.uco.pw.inscription;

/**
 * Clase extendida de AbstractRegister para la inscripcion temprana dentro del sistema.
 * @author Antonio Jiménez Jiménez
 * @author Carlos Marín Rodríguez
 * @author Gonzalo Márquez de Torres
 * @author José María Muñoz López
 * @since 05-10-2023
 * @version 1.0
 */

public class EarlyInscription extends AbstractRegister{
	
	/**
	* Constructor vacio de la inscripcion temprana
	* @param none
	* @return none
	*/
	
	public EarlyInscription() {
		
	}
	
	/**
	 * Constructor de la clase inscripcion temprana
	 * @param type El tipo de inscripcion a realizar
	 * @return none
	*/
	
	public EarlyInscription(int type){
		this.type=type;		
	}
}