package es.uco.pw.gestor;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

import es.uco.pw.asistent.Asistent;
import es.uco.pw.utils.FileUtils;

/**
 * Clase que representa el gestor de un asistente dentro del sistema.
 * @author Antonio Jiménez Jiménez
 * @author Carlos Marín Rodríguez
 * @author Gonzalo Márquez de Torres
 * @author José María Muñoz López
 * @since 05-10-2023
 * @version 1.0
 */
 
public class GestorAsistentes {
 
    public static void main(Scanner myObj) throws ParseException, IOException {
		int opcion=99;
		
		/**
		 * Se procede a leer el archivo de asistentes ya creados
		 */
		FileUtils fileUtils = new FileUtils();
		HashMap<Integer, Asistent> asistentMap = fileUtils.getAsistentMap();
		
		/**
		 * Creamos un menu donde el usuario debe elegir entre los valores que aparecen en este
		 */
		
		while(opcion != 0 ) {
			System.out.println("Indique una opcion");
			System.out.println("1.- Añadir asistente");
			System.out.println("2.- Modificar asistente");
			System.out.println("3.- Listar asistentes");
			System.out.println("0.- Guardar y salir al menu superior");
			opcion = Integer.parseInt(myObj.nextLine());
 

			switch (opcion) {
				
				/**
				 * OPCION 1: Añadir un asistente
				 * Se introducen los datos del usuario que se pretende introducir.
				 * En caso de que no coincida con los datos de otro usuario se introduce en el sistema.
				 */
				case 1: {
					boolean existeUsu=false;
	                int IdNuevo=0;
	                /**
	                 * Para evitar que se repitan los IDs, se coge el ultimo creado y se incrementa 
	                 */
	    			for (Map.Entry<Integer, Asistent> set : asistentMap.entrySet()) {
	                    if(set.getKey()>IdNuevo){
	                    	IdNuevo= set.getKey();
	                    }
	                }
	                IdNuevo = IdNuevo + 1;
	
					String nombreNuevo, apellidoNuevo;
					System.out.println("Indique nombre del nuevo asistente");
					nombreNuevo = myObj.nextLine();
	 
					System.out.println("Indique apellido del nuevo asistente");
					apellidoNuevo = myObj.nextLine();
	 
					System.out.println("-----");
					System.out.println("Indique fecha de nacimiento del nuevo asistente (dd/mm/aaaa)");
					String fechaN = myObj.nextLine();
					SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy"); 
					Date fecha = formato.parse(fechaN);
	
	                boolean atencion=false;
	                int atencion_especial=10;
	                while(!(atencion_especial == 1 || atencion_especial ==2 )) {
				        System.out.println("Indique una opcion");
				        System.out.println("1.- No requiere atención especial");
				        System.out.println("2.- Requiere atención especial");
				        atencion_especial = Integer.parseInt(myObj.nextLine());
	                }
	                
	                if(atencion_especial==2){
	                    atencion=true;
	                }
	                
	                Asistent persona=new Asistent(IdNuevo, nombreNuevo, apellidoNuevo, fecha, atencion);
	                
					if(asistentMap.size()!=0){
						for (Map.Entry<Integer, Asistent> set : asistentMap.entrySet()) {
							Asistent a = set.getValue();
							System.out.println("--Buscando asistente");
							System.out.println(a.getName()+"---"+persona.getName()+"---");
							if( nombreNuevo.equals( a.getName() ) ){
								if( apellidoNuevo.equals( a.getSurname() ) ){
								existeUsu=true;
								System.out.println("Esta persona ya existe");
								}
							}
						}
	 
					}
					if(existeUsu==false){ asistentMap.put(IdNuevo, persona);}
					break;
				}
				
				/**
				 * OPCION 2: Modificar los datos de un asistente
				 * Se introducen el ID del usuario que se desea modificar y se modifican los parametros necesarios
				 * En caso de no encontrar el ID, se cancela la busqueda.
				 */
				case 2: {// Modificar asistente
					System.out.println("Indique el ID del asistente a buscar");
					int IDSearch = Integer.parseInt(myObj.nextLine());
	
					
					Asistent asistent = asistentMap.get(IDSearch);
					if(asistent != null) {
						System.out.println("Indique el nombre para modificar");
						asistent.setName(myObj.nextLine());
						System.out.println("Indique el apellido para modificar");
						asistent.setSurname(myObj.nextLine());
							
						System.out.println("Indique fecha de nacimiento para modificar (dd/mm/aaaa)");														
						String fechaNModif = myObj.nextLine();
						SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy"); 
						asistent.setDate(formato.parse(fechaNModif));
															
						boolean atencion=false;
						int atencion_especial=10;
		                while(!(atencion_especial == 1 || atencion_especial ==2 )) {
					        System.out.println("Indique una opcion");
					        System.out.println("1.- No requiere atención especial");
					        System.out.println("2.- Requiere atención especial");
					        atencion_especial = Integer.parseInt(myObj.nextLine());
		                }
		                
		                if(atencion_especial==2){
		                    atencion=true;
		                }
		                asistent.setEspecial(atencion);
		                asistentMap.put(asistent.getID(), asistent);
					}else {
						System.out.println("Este Asistent no existe");
					}
					break;
				}
				
				/**
				 * OPCION 3: Mostrar los asistentes
				 * Se listan todos los asistentes del sistema.
				 */
				case 3: {
					for (Map.Entry<Integer, Asistent> set : asistentMap.entrySet()) {
						Asistent a = set.getValue();
						System.out.println("-----");
						System.out.println(a.toString());
					}
					break;
				}
 			}
		}
		
		/**
		 * Cuando finalizan las operaciones, se guardan todos los datos.
		 */
		fileUtils.setAsistentMap(asistentMap);
		fileUtils.saveFiles();
	}
}
