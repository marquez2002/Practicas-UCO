package es.uco.pw.activity;

import es.uco.pw.monitor.*;
import java.util.*;

/**
 * Clase que representa una actividad dentro del sistema.
 * @author Antonio Jiménez Jiménez
 * @author Carlos Marín Rodríguez
 * @author Gonzalo Márquez de Torres
 * @author José María Muñoz López
 * @since 28-09-2023
 * @version 1.0
 */

public class Activity{
	
	/**
	 * Nombre de una determinada actividad
	 */
	private String name;
	
	/**
	 * Nivel de educacion para una determinada actividad
	 */
	private LevelEducation levelEducation;
	
	/**
	 * Horario de una determinada actividad
	 */
	private Timetable timetable;
	
	/**
	 * Maximo numero de asistentes de una determinada actividad
	 */
	private int maximumAsistent;
	
	/**
	 * Numero de monitores necesarios de una determinada actividad
	 */
	private int numberMonitor;
	
	/**
	 * Lista de monitores en una determinada actividad
	 */
	private List<Monitor> monitorList;
	

	/**
	 * Enumaracion que representa los niveles de educacion para realizar la actividad
	 */
	public enum LevelEducation{
		
		/**
		 * Nivel Infantil, entre 4 y 6 años, en una determinada actividad
		 */
		INFANTIL,
		
		/**
		 * Nivel Juvenil, entre 7 y 12 años, en una determinada actividad
		 */
		JUVENIL,
		
		/**
		 * Nivel Adolescente, entre 13 y 17 años, en una determinada actividad
		 */
		ADOLESCENTE
	}
	
	/**
	 * Enumaracion que representa el horario de una actividad
	 */
	public enum Timetable{
		/**
		 * Horario de mañana en una determinada actividad
		 */
		MANANA,
		/**
		 * Horario de tarde en una determinada actividad
		 */
		TARDE
	}
	
    /**
    * Constructor vacio de la clase actividad
    * @param none
    * @return none
	*/
	 
	public Activity(){	
		monitorList = new ArrayList<>();
	}
	
    /**
    * Constructor de la clase actividad
    * @param name El nombre de la actividad
    * @param levelEducation El nivel de dificultad de la actividad
    * @param timetable El horario de la actividad
    * @param maximunAsistent El numero maximo de asistentes que pueden asistir a la actividad
    * @param numberMonitor El numero de monitores asignados a la actividad
    * @return none
	*/
	 
	public Activity(String name, LevelEducation levelEducation, Timetable timetable, int maximumAsistent, int numberMonitor){
		this.name=name;
		this.levelEducation=levelEducation;
		this.timetable=timetable;
		this.maximumAsistent=maximumAsistent;
		this.numberMonitor=numberMonitor;
		monitorList = new ArrayList<>(numberMonitor);
	}

    /**
    * Devuelve el nombre de la actividad
    * @param none
    * @return name El nombre de la actividad
	*/

	public String getName(){
		return name;	
	}
	
	/**
	* Modifica el nombre de la actividad
	* @param name El nombre de la actividad
	* @return none
	*/
	 
	public void setName(String name){
		this.name=name;
	}
	
    /**
    * Devuelve el nivel exigido para realizar la actividad
    * @param none
    * @return levelEducation El nivel exigido para la actividad
	*/
	
	public LevelEducation getLevelEducation(){
		return levelEducation;
	}
 
	/**
	* Modifica el nivel exigido para realizar la actividad
	* @param levelEducation El nivel exigido para la actividad
	* @return none
	*/
	
	public void setLevelEducation(LevelEducation levelEducation){
		this.levelEducation=levelEducation;
	}
	
    /**
    * Devuelve el horario de la actividad
    * @param none
    * @return timetable El horario de la actividad
	*/
	
	public Timetable getTimetable(){
		return timetable;
	}
	
	/**
	* Modifica el horario para la actividad
	* @param timetable El horario de la actividad
	* @return none
	*/
 
	public void setTimetable(Timetable timetable){
		this.timetable=timetable;
	}
	
    /**
    * Devuelve el maximo numero de asistentes de la actividad
    * @param none
    * @return maximumAsistent El maximo numero de asistentes de la actividad
	*/
	
	public int getMaximumAsistent(){
		return maximumAsistent;	
	}
	
	/**
	* Modifica el maximo numero de asistentes que pueden realizar la actividad
	* @param maximumAsistent El numero de asistentes que pueden realizar la actividad
	* @return none
	*/
 
	public void setMaximumAsistent(int maximumAsistent){
		this.maximumAsistent=maximumAsistent;
	}
	
    /**
    * Devuelve el numero de monitores de la actividad
    * @param none
    * @return numberMonitor numero de monitores de la actividad
	*/
	
	public int getNumberMonitor(){
		return numberMonitor;	
	}
	
	/**
	* Modifica el numero de monitores para realizar la actividad
	* @param numberMonitor El numero de monitores para realizar la actividad
	* @return none
	*/
 
	public void setNumberMonitor(int numberMonitor){
		this.numberMonitor=numberMonitor;
	}
	
	/**
	*  Devuelve la lista de monitores de la actividad
	* @param none
	* @return monitorList La lista de monitores de la actividad
	*/
	public List<Monitor> getMonitorList() {
		return monitorList;
	}

	/**
	* Modifica la lista de monitores de la actividad
	* @param monitorList La lista de monitores de la actividad
	* @return none
	*/
	public void setMonitorList(List<Monitor> monitorList) {
		this.monitorList = monitorList;
	}
	

    /*
    * Muestra la informacion referente a una actividad
    * @param none
    * @return actividadInfo La informacion de la actividad
	*/
	
	@Override
	public String toString() {
		String actividadInfo="El nombre de la actividad es "+this.name+" de nivel "+this.levelEducation+" y horario "+this.timetable+". El número de máximo de participantes será "+this.maximumAsistent+" y habrá "+this.numberMonitor+" monitores, siendo estos "+monitorList;
		return actividadInfo;
	}
	
    /*
    * Asocia un monitor de la lista de monitores a un actividad determinada siempre y cuando no se haya superado el límite
    * @param Monitor Lista de monitores dentro del campamento
    * @return String
	*/
	
	public boolean asociarMonitor(Monitor monitor){
		if(monitorList.size() < numberMonitor) {
			for (Monitor m : monitorList) {
				if(m.getId() == monitor.getId()) {
					System.out.println("El monitor ya esta asociado a la actividad.");
					return false;
				}
			}
			monitorList.add(monitor);
			return true;
		}
		
		System.out.println("Se ha alcanzado el máximo número de monitores para esta actividad.");
		return false;
	}
	
}