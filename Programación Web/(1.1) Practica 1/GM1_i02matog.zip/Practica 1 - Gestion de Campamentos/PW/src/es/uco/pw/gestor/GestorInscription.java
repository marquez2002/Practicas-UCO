package es.uco.pw.gestor;

import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

import es.uco.pw.asistent.Asistent;
import es.uco.pw.camp.Camp;
import es.uco.pw.inscription.Inscription;
import es.uco.pw.inscription.Inscription.TypeInscription;
import es.uco.pw.inscription.InscriptionFactory;
import es.uco.pw.utils.FileUtils;


public class GestorInscription {

	public static void main(Scanner myObj) throws ParseException, IOException {
		int opcion=99;
		
		/**
		 * Se procede a leer los archivos de los asistentes, inscripciones y campamentos
		 */
		FileUtils fileUtils = new FileUtils();
		ArrayList<Inscription> inscriptionList = fileUtils.getInscriptionList();
		HashMap<Integer, Asistent> asistentMap = fileUtils.getAsistentMap();
		HashMap<Integer, Camp> campMap = fileUtils.getCampMap();
		
		/**
		 * Creamos un menu donde el usuario debe elegir entre los valores que aparecen en este
		 */
		while(opcion != 0 ) {
			System.out.println("Indique una opcion");
			System.out.println("1.- Realizar Inscripcion");
			System.out.println("2.- Consultar Campamentos Disponibles");
			System.out.println("3.- Listar todas las inscripciones");
			System.out.println("0.- Guardar y salir al menu superior");
			opcion = Integer.parseInt(myObj.nextLine());
 
			/**
			 * OPCION 1: Realizar una inscripcion
			 * Deben existir campamentos y asistentes antes para poder realizar la inscripcion
			 * Se introducen el id del campamento al que se desea inscribiry se comprueba su existencia, si hay actividades asignadas o si esta completo.
			 * Se introduce el id del asistente, se comprueba su existencia y se asocia al mismo.
			 */
			switch (opcion) {
				case 1: {// Realizar inscripcion
					Camp camp = null;
					boolean camps_available = false;
					while (camp == null) {
						System.out.println("Introduzca el id del campamento en el que desea inscribir");
						for (Map.Entry<Integer, Camp> set : campMap.entrySet()) {
							Camp c = set.getValue();
							System.out.println("-----");
							System.out.println(c.toString());
							System.out.println("-----");
							camps_available = true;

						}

						if (camps_available) {
							camp = campMap.get(Integer.parseInt(myObj.nextLine()));
							if (camp == null) {
								System.out.println("El id introducido no corresponde con ningun campamento.");
							} else if (camp.getActivityList().size() == 0){
								System.out.println("El campamento seleccionado no cuenta aun con actividades, asegurese de asignarlas antes.");
								camp = null;
							} else {
								int numInscptionsCamp = 0;
								for(Inscription i : inscriptionList) {
									if(i.getIdCamp() == camp.getID()) {
										numInscptionsCamp++;
									}
								}
								if(numInscptionsCamp == camp.getMaximunAsistent()) {
									System.out.println("El campamento esta completo y no permite mas inscripciones");
									camp = null;
								}else {
									Asistent asistent = null;
									boolean asistent_available = false;
									while (asistent == null) {
										System.out.println("Introduzca el id del asistente que desea inscribir");
										for (Map.Entry<Integer, Asistent> set : asistentMap.entrySet()) {
											Asistent a = set.getValue();
											System.out.println("-----");
											System.out.println(a.toString());
											System.out.println("-----");
											asistent_available = true;
		
										}
		
										if (asistent_available) {
											asistent = asistentMap.get(Integer.parseInt(myObj.nextLine()));
											if (asistent == null) {
												System.out.println("El id introducido no corresponde con ningun asistente.");
											}else {
												boolean existInscription = false;
												for(Inscription i : inscriptionList) {
													if(i.getIdCamp() == camp.getID() && i.getIdAsistent() == asistent.getID()) {
														existInscription = true;
													}
												}
												
												if(existInscription) {
													System.out.println("El asistent ya esta inscrito en este campamento.");
													asistent=null;
												}else {
													int type_inscription_id = 0;
													while (type_inscription_id < 1 || type_inscription_id > 2) {
														System.out.println("Indique una opcion");
														System.out.println("1.- Inscripcion completa (Mañana y tarde)");
														System.out.println("2.- Inscripcion parcial (Solo mañana)");
														type_inscription_id = Integer.parseInt(myObj.nextLine());
													}
				
													TypeInscription typeInscription = TypeInscription.COMPLETA;
													if (type_inscription_id == 2) {
														typeInscription = TypeInscription.PARCIAL;
													}
													
													Inscription inscription = InscriptionFactory.createInscription(asistent, camp, typeInscription);
													if (inscription == null) {
														System.out.println("La inscripcion en este campamento ya no esta habilitada.");
													} else {
														/**
														 * En caso de que necesite atencion especial, y si el primero que lo necesita, modificamos el campamento para asignar un monitor de educacion esepcial 
														 */
														if(asistent.getEspecial() && !camp.getNeededSpecialMonitor()) {
															System.out.println("Debe seleccionar un monitor especial para este campamento, ya que ahora hay una persona inscrita con este necesidad.");
															camp.setNeedSpecialMonitor(true);
															campMap.put(camp.getID(), camp);
														}
														inscriptionList.add(inscription);
													}
												}
											}
										} else {
											System.out.println("No hay asistentes aun, asegurese de crearlos antes.");
											break;
										}
									}
								}
							}
						} else {
							System.out.println("No hay campamentos aun, asegurese de crearlos antes.");
							break;
						}
					}
					break;
				}
				
				/**
				 * OPCION 2: Listar campamentos disponibles
				 * Se listan todos los campamentos disponibles en los que se puede inscribir los asistentes.
				 */
				case 2: {
					for (Map.Entry<Integer, Camp> set : campMap.entrySet()) {
						Camp c = set.getValue();
						Date today = new Date();
						
						if(today.before(c.getStartDate())) {
							int numInscptionsCamp = 0;
							for(Inscription i : inscriptionList) {
								if(i.getIdCamp() == c.getID()) {
									numInscptionsCamp++;
								}
							}
							if(numInscptionsCamp < c.getMaximunAsistent()) {
								System.out.println("-----");
								System.out.println(c.toString());
								System.out.println("-----");
							}
						}
					}
					break;
				}
				
				/**
				 * OPCION 3: Listar inscripciones
				 * Se listan las inscripciones ya realizadas en el sistema.
				 */
				case 3: {// Mostrar inscripciones
					for (Inscription i : inscriptionList) {
						System.out.println("-----");
						System.out.println(i.toString());
	 
					}
					break;
				}
			}
				
		}
		
		/**
		 * Cuando finalizan las operaciones, se guardan todos los datos.
		 */
		fileUtils.setInscriptionList(inscriptionList);
		fileUtils.setCampMap(campMap);
		fileUtils.saveFiles();
	}
}