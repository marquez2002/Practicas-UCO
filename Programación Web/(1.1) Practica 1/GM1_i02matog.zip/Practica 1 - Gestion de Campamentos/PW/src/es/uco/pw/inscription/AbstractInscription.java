package es.uco.pw.inscription;

import es.uco.pw.camp.*;
import es.uco.pw.asistent.*;

import java.text.SimpleDateFormat;
import java.util.*;

/**
 * Clase abstracta que representa una inscripcion dentro del sistema.
 * @author Antonio Jiménez Jiménez
 * @author Carlos Marín Rodríguez
 * @author Gonzalo Márquez de Torres
 * @author José María Muñoz López
 * @since 04-10-2023
 * @version 1.0
 */

public abstract class AbstractInscription{
	
	/**
	 * ID del asistente que realiza la inscripcion
	 */
	private int idAsistent;
	
	/**
	 * ID del campamento que realiza la inscripcion
	 */
	private int idCamp;
	
	/**
	 * Fecha en la que se realiza la inscripcion
	 */
	private Date inscriptionDate;
	
	/**
	 * Precio de la inscripcion
	 */
	private float price;
	
	/**
	 * Tipo de inscripcion
	 */
	private BaseInscription inscription;
	

	/**
	 * Enumaracion que representa el tipo de inscripcion a realizar
	 */
	
	public enum BaseInscription{
		
		/**
		 * Inscripcion Completa, se inscribe todo el dia, tanto mañana como tarde
		 */
		COMPLETA,
		
		/**
		 * Inscripcion Parcial, se inscribe solo en horario de mañaa
		 */
		PARCIAL
	}
	
	
	/**
	* Declaracion del metodo de Inscripcion Temprana
	* @param none
	* @return none
	*/
	
	public abstract EarlyInscription earlyRegister();
	
	/**
	* Declaracion del metodo de Inscripcion Tardia
	* @param none
	* @return none
	*/
	
	public abstract LateInscription lateRegister();
	 
	/**
	* Constructor vacio de la clase inscripcion
	* @param none
	* @return none
	*/
	 
	public AbstractInscription(){	
		
	}
	 
	/**
	* Devuelve el identificador del asistente que realiza la inscripcion
	* @param none
	* @return idAsistent El identificador del asistente que realiza la inscripcion
	*/
	
	public int getIDAsistent(){
		return idAsistent;
	}
	
	/**
	* Modifica el id del asistente de la persona que realiza la inscripcion
	* @param idAsistent El id del asistente
	* @return none
	*/
	
	public void setIDAsistent(Asistent asistente) {
		this.idAsistent=asistente.getID();
	}
	
	/**
	* Devuelve el identificador del campamento
	* @param none
	* @return idCamp El identificador del campamento 
	*/
	
	public int getIDCamp(){
		return idCamp;
	}
	
	/**
	* Modifica el identificador del campamento 
	* @param idCamp El identificador del campamento
	* @return none
	*/
	
	public void setIDCamp(Camp campamento) {
		this.idCamp=campamento.getID();
	}
	
	/**
	* Devuelve la fecha de la inscripcion al campamento
	* @param none
	* @return inscriptionDate La fecha de la inscripcion al campamento
	*/
	
	public Date getInscriptionDate(){
		return inscriptionDate;
	}
	
	/**
	* Modifica la fecha de inscripcion del campamento
	* @param inscriptionDate La fecha de inscripcion del campamento
	* @return none
	*/
	
	public void setIDCamp(Date inscriptionDate) {
		this.inscriptionDate=inscriptionDate;
	}
	
	/**
	* Devuelve la fecha de inscripcion al campamento
	* @param none
	* @return price El precio de la inscripcion
	*/
	
	public Float getPrice(){
		return price;
	}
	
	/**
	* Modifica el precio de inscripcion del campamento
	* @param price El precio de inscripcion del campamento
	* @return none
	*/
	
	public void setPrice(float price) {
		this.price=price;
	}
	
	/**
	* Devuelve el tipo de inscripcion al campamento
	* @param none
	* @return inscription El tipo de inscripcion al campamento
	*/
	
	public BaseInscription getInscription(){
		return inscription;
	}
	
	/**
	* Modifica el tipo de inscripcion al campamento
	* @param inscription El tipo de inscripcion al campamento
	* @return none
	*/
	
	public void setBaseInscription(BaseInscription inscription) {
		this.inscription=inscription;
	}
	
	/*
	* Muestra la informacion referente a una inscripcion
	* @param none
	* @return inscripctionInfo La informacion de la inscripcion
	*/
	
	@Override
	public String toString() {
		SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy");
        String inscriptionDateString = formato.format(getInscriptionDate());
		String inscriptionInfo="La inscripcion del asistente "+this.idAsistent+" para el campamento "+this.idCamp+". Con fecha de inscripcion en "+inscriptionDateString +", con precio"+this.price+" y a tiempo "+this.inscription+".";
		return inscriptionInfo;
	}
}