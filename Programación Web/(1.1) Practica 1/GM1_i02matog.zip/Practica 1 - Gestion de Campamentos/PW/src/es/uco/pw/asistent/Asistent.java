package es.uco.pw.asistent;

import java.util.*;
import java.text.SimpleDateFormat;
/**
 * Clase que representa un asistente dentro del sistema.
 * @author Antonio Jiménez Jiménez
 * @author Carlos Marín Rodríguez
 * @author Gonzalo Márquez de Torres
 * @author José María Muñoz López
 * @since 27-09-2023
 * @version 1.0
 */

public class Asistent {
	
	/**
	 * Identificador de un determinado asistente
	 */
	private int id;
	
	/**
	 * Nombre de un determinado asistente
	 */
	private String name;
	
	/**
	 * Apellido de un determinado asistente
	 */
	private String surname;
	
	/**
	 * Fecha de nacimiento de un determinado asistente
	 */
	private Date date;
	
	/**
	 * Si es necesario algun tipo de tratamiento especial en un determinado asistente
	 */
	private boolean especial;
	 
	 
    /**
    * Constructor vacio de la clase asistente
    * @param none
    * @return none
	*/
	public Asistent(){	
		
	}
	 
    /**
    * Constructor de la clase asistente
    * @param id El identificador del asistente
    * @param name El nombre del asistente
    * @param surname El apellido del asistente 
    * @param date La fecha de nacimiento del asistente
    * @param especial Parametro para determinar si necesita educacion especial el asistente
    * @return none
	*/
	
	public Asistent(int id, String name, String surname, Date date, boolean especial){
		this.id=id;
		this.name=name;
		this.surname=surname;
		this.date=date;
		this.especial=especial;
	}
	 
    /**
    * Devuelve el identificador del asistente
    * @param none
    * @return id El identificador del asistente
	*/
	 
	public int getID(){
		return id;
	}
	
	/**
	* Modifica el identificador del asistente
	* @param id El identificador del asistente
	* @return none
	*/
	 
	public void setID(int id) {
		this.id=id;
	}
	
	/**
	* Devuelve el nombre del asistente
	* @param none
	* @return name El nombre del asistente
	*/
	
	public String getName() {
		return name;	
	}
	
	/**
	* Modifica el nombre del asistente
	* @param name El nombre del asistente
	* @return none
	*/
	 
	public void setName(String name){
		this.name=name;
	}
		
	/**
	* Devuelve el apellido del asistente
	* @param none
	* @return surname El apellido del asistente
	*/
	
	public String getSurname() {
		return surname;	
	}
	
	/**
	* Modifica el apellido del asistente
	* @param surname El apellido del asistente
	* @return none
	*/
	 
	public void setSurname(String surname){
		this.surname=surname;
	}
	
	/**
	* Devuelve la fecha de nacimiento del asistente
	* @param none
	* @return date La fecha de nacimiento del asistente
	*/
	 
	public Date getDate(){
		return date;
	}
	
	/**
	* Modifica la fecha de nacimiento del asistente
	* @param date La fecha de nacimiento del asistente
	* @return none
	*/
	 
	public void setDate(Date date){
		this.date=date;
	}
	
	/**
	* Devuelve si el asistente requiere atencion especial
	* @param none
	* @return especial Confima si el asistente requiere atencion especial
	*/
	
	public boolean getEspecial() {
		return especial;
	}
	
	/**
	* Modifica si el asistente requiere atencion especial
	* @param especial Confirma si el asistente requiere atencion especial
	* @return none
	*/
 
	public void setEspecial(boolean especial){
		this.especial=especial;
	}
	 
	/*
	 Muestra la informacion referente a un asistente
	* @param none
	* @return asistenteInfo La informacion del asistente
	*/
	
	@Override
	public String toString() {
		SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy");
        String dateString = formato.format(getDate());
		String asistenteInfo="El ID del asistente es "+this.id+", con nombre "+this.name+" "+this.surname+" y fecha de nacimiento "+dateString+".";
		if(especial == true){
			asistenteInfo +=" Tendrá que recibir atención especial.";
		}
		else {
			asistenteInfo +=" No tendrá que recibir atención especial.";
		}
		return asistenteInfo;
	}
}
