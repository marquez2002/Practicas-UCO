package es.uco.pw.inscription;

import java.time.*;
import java.util.*;

import es.uco.pw.asistent.Asistent;
import es.uco.pw.camp.Camp;
import es.uco.pw.inscription.Inscription.TimeInscription;
import es.uco.pw.inscription.Inscription.TypeInscription;

/**
 * Clase que representa el factory de un inscripcion pudiendo seleccionar entre inscripcion parcial o completa.
 * @author Antonio Jiménez Jiménez
 * @author Carlos Marín Rodríguez
 * @author Gonzalo Márquez de Torres
 * @author José María Muñoz López
 * @since 10-10-2023
 * @version 1.0
 */

public class InscriptionFactory {
	
	/**
	 * Crea una inscripcion difenrenciando entre temprana o tardia.
	 * @param asistent Asistente a inscribir
	 * @param camp Campamento que se va inscribir
	 * @param date Fecha de la inscripcion
	 * @param price Precio de la inscripcion
	 * @param typeInscription Tipo de inscripcion
	 * @param timeInscription Tiempo hasta que comience el campamento
	 * @return Inscription La inscripcion dependiendo de si es temprana o tardia
	 */
	public static Inscription createInscription(Asistent asistent, Camp camp, Date date, float price, TypeInscription typeInscription, TimeInscription timeInscription) {
		if(timeInscription == TimeInscription.TEMPRANA) {
			return new InscriptionTemprana(asistent.getID(), camp.getID(), date, price, typeInscription);
		} else if(timeInscription == TimeInscription.TARDIA){
			return new InscriptionTardia(asistent.getID(), camp.getID(), date, price, typeInscription);
		}
		
		return null;
	}
	
	/**
	 * Creacion de una inscripcion variando tanto el precio inicial como el tipo de inscripcion
	 * @param asistent Asistente a inscribir
	 * @param camp Campamento que se va inscribir
	 * @param typeInscription Tipo de inscripcion
	 * @return
	 */
	public static Inscription createInscription(Asistent asistent, Camp camp, TypeInscription typeInscription) {
		Date today = new Date();
		float price = 300;
		if(typeInscription == TypeInscription.PARCIAL) {
			/**
			 * Si la inscripcion es parcial se reduce 100€ el precio inicial
			 */
			price-=100;
		}
		/**
		 * Por actividad, se incrementa el precio 20€
		 */
		price += camp.getActivityList().size()*20;
		
		/**
		 * Se comprueba la fecha de inscripcion con la fecha del campamento, para variar entre inscripcion tardia o temprana
		 */
		Instant now = Instant.now();
		Date within15days = Date.from(now.plus(Duration.ofDays(15)));
		if(camp.getStartDate().after(within15days)) {
			return new InscriptionTemprana(asistent.getID(), camp.getID(), today, price, typeInscription);
		}else {
			Date within2days = Date.from(now.plus(Duration.ofDays(2)));
			if(camp.getStartDate().after(within2days)) {
				return new InscriptionTardia(asistent.getID(), camp.getID(), today, price, typeInscription);
			}
		}	
		return null;
	}
}
