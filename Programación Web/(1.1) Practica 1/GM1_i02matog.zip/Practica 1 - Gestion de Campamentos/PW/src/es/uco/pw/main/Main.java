package es.uco.pw.main;

import java.io.IOException;
import java.text.ParseException;
import java.util.Scanner;

import es.uco.pw.gestor.GestorAsistentes;
import es.uco.pw.gestor.GestorCamps;
import es.uco.pw.gestor.GestorInscription;

/**
 * Clase Main dentro del sistema.
 * @author Antonio Jiménez Jiménez
 * @author Carlos Marín Rodríguez
 * @author Gonzalo Márquez de Torres
 * @author José María Muñoz López
 * @since 10-10-2023
 * @version 1.0
 */

public class Main{
  
	public static void main(String[] args) throws ParseException, IOException{
		Scanner myObjMain = new Scanner(System.in);
		int opcionMain=99;
		
		/**
		 * Menu de opciones dentro del menu del Main
		 */
		while(opcionMain != 0 ) {
			System.out.println("Indique una opcion");
			System.out.println("1.- Gestor de Asistentes");
			System.out.println("2.- Gestor de Campamentos");
			System.out.println("3.- Gestor de Inscripciones");
			System.out.println("0.- Salir");
			opcionMain = Integer.parseInt(myObjMain.nextLine());
			
			
			switch (opcionMain) {
				/**
			 	* OPCION 1: Accede al gestor de asistentes
			 	*/
				case 1:
					GestorAsistentes.main(myObjMain);
					break;
				/**
				* OPCION 2: Accede al gestor de campamentos
				*/
				case 2:
					GestorCamps.main(myObjMain);
					break;
				/**
				* OPCION 3: Accede al gestor de inscripciones
				*/				
				case 3:
					GestorInscription.main(myObjMain);
					break;
			}
		}
		myObjMain.close();
	}
}
