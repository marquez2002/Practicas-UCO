package es.uco.pw.inscription;

import es.uco.pw.camp.*;
import es.uco.pw.asistent.*;

import java.text.SimpleDateFormat;
import java.util.*;

/**
 * Clase abstracta que representa una inscripcion dentro del sistema.
 * @author Antonio Jiménez Jiménez
 * @author Carlos Marín Rodríguez
 * @author Gonzalo Márquez de Torres
 * @author José María Muñoz López
 * @since 04-10-2023
 * @version 1.0
 */

public abstract class Inscription{
	
	/**
	 * ID del asistente que realiza la inscripcion
	 */
	protected int idAsistent;
	
	/**
	 * ID del campamento que realiza la inscripcion
	 */
	protected int idCamp;
	
	/**
	 * Fecha en la que se realiza la inscripcion
	 */
	protected Date inscriptionDate;
	
	/**
	 * Precio de la inscripcion
	 */
	protected float price;
	 
	/**
	 * Tiempo en que se ha realizado la inscripcion
	 */
	protected TimeInscription timeInscription;
	
	/**
	 * Tipo de inscripcion
	 */
	protected TypeInscription typeInscription;
	
	/**
	* Enumaracion que representa el tiempo en que se ha realizado la inscripcion
	*/
	public enum TimeInscription{
		
		/**
		* Inscripcion realiaza de forma temprana
		*/
		TEMPRANA,
		
		/**
		* Inscripcion realiaza de forma tardia
		*/
		TARDIA
	}
	
	/**
	* Enumaracion que representa el tipo de inscripcion
	*/
	public enum TypeInscription{
		
		/**
		* Inscripcion realiaza de tipo completa, mañana y tarde
		*/
		COMPLETA,
		
		/**
		* Inscripcion realiaza de tipo parcial, solo por las mañana
		*/
		PARCIAL
	}
	 
	/**
	* Constructor vacio de la clase inscripcion
	* @param none
	* @return none
	*/
	
	public Inscription(){	
		
	}

	/**
	* Devuelve el identificador del asistente que realiza la inscripcion
	* @param none
	* @return idAsistent El identificador del asistente que realiza la inscripcion
	*/
	
	public int getIdAsistent(){
		return idAsistent;
	}
	
	/**
	* Modifica el id del asistente de la persona que realiza la inscripcion
	* @param idAsistent El id del asistente
	* @return none
	*/
	
	public void setIdAsistent(int idAsistent) {
		this.idAsistent=idAsistent;
	}
	
	/**
	* Modifica el id del asistente de la persona que realiza la inscripcion
	* @param asistente El asistente
	* @return none
	*/
	
	public void setIdAsistent(Asistent asistente) {
		this.idAsistent=asistente.getID();
	}
	
	/**
	* Devuelve el identificador del campamento
	* @param none
	* @return idCamp El identificador del campamento 
	*/
	
	public int getIdCamp(){
		return idCamp;
	}
	
	/**
	* Modifica el identificador del campamento 
	* @param idCamp El identificador del campamento
	* @return none
	*/
	
	public void setIdCamp(int idCamp) {
		this.idCamp=idCamp;
	}
	
	/**
	* Modifica el identificador del campamento 
	* @param campamento El campamento
	* @return none
	*/
	
	public void setIdCamp(Camp campamento) {
		this.idCamp=campamento.getID();
	}
	
	/**
	* Devuelve la fecha de la inscripcion al campamento
	* @param none
	* @return inscriptionDate La fecha de la inscripcion al campamento
	*/
	
	public Date getInscriptionDate(){
		return inscriptionDate;
	}
	
	/**
	* Modifica la fecha de inscripcion del campamento
	* @param inscriptionDate La fecha de inscripcion del campamento
	* @return none
	*/
	
	public void setInscriptionDate(Date inscriptionDate) {
		this.inscriptionDate=inscriptionDate;
	}
	
	/**
	* Devuelve la fecha de inscripcion al campamento
	* @param none
	* @return price El precio de la inscripcion
	*/
	
	public Float getPrice(){
		return price;
	}
	
	/**
	* Modifica el precio de inscripcion del campamento
	* @param price El precio de inscripcion del campamento
	* @return none
	*/
	
	public void setPrice(float price) {
		this.price=price;
	}
	
	/**
	* Devuelve el tiempo de inscripcion 
	* @param none
	* @return timeInscription El tiempo de la inscripcion
	*/
	
	public TimeInscription getTimeInscription(){
		return timeInscription;
	}
	
	/**
	* Modifica el tiempo de inscripcion 
	* @param timeInscription El tiempo de inscripcion 
	* @return none
	*/
	
	public void setTimeInscription(TimeInscription timeInscription ) {
		this.timeInscription=timeInscription;
	}
	
	/**
	* Devuelve el tipo de inscripcion
	* @param none
	* @return typeInscription El tipo de la inscripcion
	*/
	
	public TypeInscription getTypeInscription(){
		return typeInscription;
	}
	
	/**
	* Modifica el tipo de inscripcion
	* @param typeInscription El tipo de inscripcion
	* @return none
	*/
	
	public void setTypeInscription(TypeInscription typeInscription ) {
		this.typeInscription=typeInscription;
	}
	
	/*
	* Muestra la informacion referente a una inscripcion
	* @param none
	* @return inscripctionInfo La informacion de la inscripcion
	*/
	
	@Override
	public String toString() {
		SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy");
        String inscriptionDateString = formato.format(getInscriptionDate());
		String inscriptionInfo="La inscripcion del asistente "+this.idAsistent+" para el campamento "+this.idCamp+". Con fecha de inscripcion en "+inscriptionDateString + ". Con importe de " + this.price + "€.";
		
		switch (this.typeInscription) {
			case COMPLETA: {
				inscriptionInfo +=" La inscripción es de tipo completa.";
				break;
			}
			case PARCIAL: {
				inscriptionInfo +=" La inscripción es de tipo parcial.";
				break;
			}
		}
		
		return inscriptionInfo;
	}
	
	
	/*
	* Indica si la inscription puede ser cancelada o no
	* @param none
	* @return boolean Si la inscription puede ser cancelada o no
	*/
	public abstract boolean allowCancellation();
}