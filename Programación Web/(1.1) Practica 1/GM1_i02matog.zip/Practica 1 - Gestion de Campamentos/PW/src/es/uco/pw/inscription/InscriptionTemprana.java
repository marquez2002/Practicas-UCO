package es.uco.pw.inscription;

import java.util.Date;

/**
 * Clase que representa la inscripcion temprana de una reserva dentro del sistema.
 * @author Antonio Jiménez Jiménez
 * @author Carlos Marín Rodríguez
 * @author Gonzalo Márquez de Torres
 * @author José María Muñoz López
 * @since 10-10-2023
 * @version 1.0
 */

public class InscriptionTemprana extends Inscription {

	/**
	 * Constructor de la clase inscription temprana
	 * @return none
	*/
	public InscriptionTemprana(){
		this.timeInscription=TimeInscription.TEMPRANA;
	}

	/**
	 * Constructor de la clase inscription temprana
	 * @param idAsistent El identificador del asistente
	 * @param idCamp El identificador del campamento
	 * @param price El precio de la inscripcion
	 * @param typeInscription El tipo de la inscripcion
	 * @return none
	*/
	public InscriptionTemprana(int idAsistent, int idCamp, Date date, float price, TypeInscription typeInscription){
		this.idAsistent=idAsistent;
		this.idCamp=idCamp;
		this.price=price;
		this.typeInscription= typeInscription;
		this.inscriptionDate = date;
		this.timeInscription=TimeInscription.TEMPRANA;
	}
	
	
	/*
	* Muestra la informacion referente a una inscripcion temprana
	* @param none
	* @return inscripctionInfo La informacion de la inscripcion
	*/
	@Override
	public String toString() {
		return super.toString() + " La inscripción es de tipo temprana.";
	}
	
	/*
	* Indica si se permite la cancelacion
	* @param none
	* @return false La inscripcion no se puede cancelar
	*/
	@Override
	public boolean allowCancellation() {
		return true;
	}
}