package es.uco.pw.inscription;

/**
 * Clase extendida de AbstractRegister para la inscripcion tardia dentro del sistema.
 * @author Antonio Jiménez Jiménez
 * @author Carlos Marín Rodríguez
 * @author Gonzalo Márquez de Torres
 * @author José María Muñoz López
 * @since 05-10-2023
 * @version 1.0
 */

public class LateInscription extends AbstractRegister{

	/**
	* Constructor vacio de la inscripcion tardia
	* @param none
	* @return none
	*/
	public LateInscription() {
		
	}
	
	/**
	 * Constructor de la clase inscripcion tardia
	 * @param type El tipo de inscripcion a realizar
	 * @return none
	*/
	public LateInscription(int type) {
		this.type=type;
	}
}
