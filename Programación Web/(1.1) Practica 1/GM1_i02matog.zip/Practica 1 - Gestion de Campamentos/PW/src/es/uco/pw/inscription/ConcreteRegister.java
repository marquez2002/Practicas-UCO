package es.uco.pw.inscription;

/**
 * Clase abstracta que concreta el tipo de inscripcion que va a realizar una inscripcion dentro del sistema.
 * @author Antonio Jiménez Jiménez
 * @author Carlos Marín Rodríguez
 * @author Gonzalo Márquez de Torres
 * @author José María Muñoz López
 * @since 04-10-2023
 * @version 1.0
 */

public class ConcreteRegister extends AbstractInscription{

	/*
	* Metodo para determina si la inscripcion es temprana o tardia
	* @param none
	* @return register El tipo de inscripcion realizada
	*/
	
	@Override
	public EarlyInscription earlyRegister() {
		EarlyInscription register = new EarlyInscription(0);
		return register;
	}
	
	/*
	* Metodo para determina si la inscripcion es temprana o tardia
	* @param none
	* @return register El tipo de inscripcion realizada
	*/

	@Override
	public LateInscription lateRegister() {
		LateInscription register = new LateInscription(1);
		return register;
	}
}
