-- phpMyAdmin SQL Dump
-- version 2.7.0-pl2
-- http://www.phpmyadmin.net
-- 
-- Servidor: oraclepr.uco.es
-- Tiempo de generación: 12-11-2023 a las 19:36:16
-- Versión del servidor: 5.1.73
-- Versión de PHP: 5.3.3
-- 
-- Base de datos: `i02jijia`
-- 

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `Activity`
-- 

CREATE TABLE `Activity` (
  `id` int(64) NOT NULL AUTO_INCREMENT,
  `idCamp` int(64) NOT NULL DEFAULT '0',
  `name` varchar(64) NOT NULL,
  `level_education` int(3) DEFAULT NULL,
  `timetable` int(2) DEFAULT NULL,
  `maximumAsistent` int(64) NOT NULL,
  `numberMonitor` int(64) NOT NULL,
  `numberMonitorAsignados` int(64) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `FK_Activity_Camp` (`idCamp`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=latin1 AUTO_INCREMENT=16 ;

-- 
-- Volcar la base de datos para la tabla `Activity`
-- 

INSERT INTO `Activity` VALUES (1, 1, 'Fútbol Recreativo', 1, 1, 32, 5, 1);
INSERT INTO `Activity` VALUES (2, 2, 'Natación Infantil', 2, 2, 20, 3, 0);
INSERT INTO `Activity` VALUES (3, 3, 'Senderismo Familiar', 3, 1, 15, 2, 1);
INSERT INTO `Activity` VALUES (4, 4, 'Yoga para Todos', 1, 2, 25, 4, 2);
INSERT INTO `Activity` VALUES (5, 5, 'Arte en el Parque', 2, 1, 18, 3, 0);
INSERT INTO `Activity` VALUES (6, 6, 'Torneo de Ajedrez', 3, 2, 30, 6, 2);
INSERT INTO `Activity` VALUES (7, 7, 'Cine al Aire Libre', 1, 1, 22, 4, 1);
INSERT INTO `Activity` VALUES (8, 8, 'Clases de Cocina', 2, 2, 28, 5, 0);
INSERT INTO `Activity` VALUES (9, 9, 'Juegos de Mesa', 3, 1, 15, 2, 1);
INSERT INTO `Activity` VALUES (10, 10, 'Paseo en Bicicleta', 1, 2, 20, 3, 0);
INSERT INTO `Activity` VALUES (11, 11, 'Picnic en el Parque', 2, 1, 15, 2, 1);
INSERT INTO `Activity` VALUES (12, 12, 'Concierto al Atardecer', 3, 2, 20, 3, 0);
INSERT INTO `Activity` VALUES (13, 13, 'Clases de Fotografía', 2, 1, 15, 2, 1);
INSERT INTO `Activity` VALUES (14, 14, 'Teatro al Aire Libre', 1, 2, 25, 4, 1);
INSERT INTO `Activity` VALUES (15, 15, 'Taller de Pintura', 3, 1, 20, 3, 0);

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `ActivityCamp`
-- 

CREATE TABLE `ActivityCamp` (
  `idActivity` int(64) NOT NULL,
  `idCamp` int(64) NOT NULL,
  PRIMARY KEY (`idActivity`),
  KEY `fk_ActivityCamp` (`idCamp`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Volcar la base de datos para la tabla `ActivityCamp`
-- 

INSERT INTO `ActivityCamp` VALUES (1, 1);
INSERT INTO `ActivityCamp` VALUES (2, 2);

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `ActivityMonitor`
-- 

CREATE TABLE `ActivityMonitor` (
  `idMonitor` int(32) NOT NULL,
  `idActivity` int(32) NOT NULL,
  KEY `fk_ActivityMonitor_` (`idMonitor`),
  KEY `fk_ActivityMonitor` (`idActivity`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Volcar la base de datos para la tabla `ActivityMonitor`
-- 

INSERT INTO `ActivityMonitor` VALUES (1, 1);
INSERT INTO `ActivityMonitor` VALUES (2, 1);
INSERT INTO `ActivityMonitor` VALUES (6, 1);

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `Asistent`
-- 

CREATE TABLE `Asistent` (
  `id` int(132) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL,
  `surname` varchar(64) NOT NULL,
  `date` date NOT NULL,
  `special` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=latin1 AUTO_INCREMENT=16 ;

-- 
-- Volcar la base de datos para la tabla `Asistent`
-- 

INSERT INTO `Asistent` VALUES (1, 'Ana', 'Gonzalez', '1985-05-15', 1);
INSERT INTO `Asistent` VALUES (2, 'Carlos', 'Martinez', '1992-09-23', 0);
INSERT INTO `Asistent` VALUES (3, 'Elena', 'Rodriguez', '1988-12-10', 1);
INSERT INTO `Asistent` VALUES (4, 'Miguel', 'Lopez', '1995-03-28', 0);
INSERT INTO `Asistent` VALUES (5, 'Sofia', 'Fernandez', '1998-07-02', 1);
INSERT INTO `Asistent` VALUES (6, 'Alejandro', 'Hernandez', '1991-11-18', 0);
INSERT INTO `Asistent` VALUES (7, 'Isabel', 'Gomez', '1994-02-07', 1);
INSERT INTO `Asistent` VALUES (8, 'Javier', 'Diaz', '1987-06-14', 0);
INSERT INTO `Asistent` VALUES (9, 'Carmen', 'Perez', '1999-09-30', 1);
INSERT INTO `Asistent` VALUES (10, 'Daniel', 'Ruiz', '1993-04-25', 0);
INSERT INTO `Asistent` VALUES (11, 'Maria', 'Sanchez', '1986-08-12', 1);
INSERT INTO `Asistent` VALUES (12, 'Pablo', 'Vega', '1997-01-19', 0);
INSERT INTO `Asistent` VALUES (13, 'Laura', 'Ortega', '1990-03-03', 1);
INSERT INTO `Asistent` VALUES (14, 'Francisco', 'Molina', '1996-05-08', 0);
INSERT INTO `Asistent` VALUES (15, 'Lucia', 'Encinas', '2005-01-15', 0);

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `Camp`
-- 

CREATE TABLE `Camp` (
  `id` int(32) NOT NULL AUTO_INCREMENT,
  `startDate` date DEFAULT NULL,
  `endDate` date DEFAULT NULL,
  `levelEducation` enum('INFANTIL','JUVENIL','ADOLESCENTE') DEFAULT NULL,
  `maximumAsistent` int(64) NOT NULL,
  `neededSpecialMonitor` tinyint(1) DEFAULT '0',
  `asistents` int(64) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

-- 
-- Volcar la base de datos para la tabla `Camp`
-- 

INSERT INTO `Camp` VALUES (1, '2023-11-21', '2023-11-26', 'INFANTIL', 30, 0, 0);
INSERT INTO `Camp` VALUES (2, '2023-12-05', '2023-12-10', 'JUVENIL', 25, 1, 0);
INSERT INTO `Camp` VALUES (3, '2023-12-16', '2023-12-21', 'ADOLESCENTE', 20, 0, 0);
INSERT INTO `Camp` VALUES (4, '2023-12-31', '2024-01-05', 'INFANTIL', 35, 1, 0);
INSERT INTO `Camp` VALUES (5, '2024-01-15', '2024-01-20', 'JUVENIL', 28, 0, 0);
INSERT INTO `Camp` VALUES (6, '2024-01-26', '2024-01-31', 'ADOLESCENTE', 22, 1, 0);
INSERT INTO `Camp` VALUES (7, '2024-02-10', '2024-02-15', 'INFANTIL', 40, 0, 0);
INSERT INTO `Camp` VALUES (8, '2024-02-25', '2024-03-01', 'JUVENIL', 33, 1, 0);
INSERT INTO `Camp` VALUES (9, '2024-03-11', '2024-03-16', 'ADOLESCENTE', 26, 0, 0);
INSERT INTO `Camp` VALUES (10, '2024-03-26', '2024-03-31', 'INFANTIL', 38, 1, 0);

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `CampMonitor`
-- 

CREATE TABLE `CampMonitor` (
  `idCamp` int(11) NOT NULL,
  `idMonitor` int(11) NOT NULL,
  `responsable` tinyint(4) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Volcar la base de datos para la tabla `CampMonitor`
-- 

INSERT INTO `CampMonitor` VALUES (2, 9, 0);

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `Inscription`
-- 

CREATE TABLE `Inscription` (
  `id` int(132) NOT NULL AUTO_INCREMENT,
  `idAsistent` int(132) DEFAULT NULL,
  `idCamp` int(132) DEFAULT NULL,
  `inscriptionDate` date NOT NULL,
  `price` float NOT NULL,
  `TimeInscription` tinyint(4) NOT NULL,
  `TypeInscription` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_Inscription_Asistente` (`idAsistent`),
  KEY `FK_Inscription_Camp` (`idCamp`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

-- 
-- Volcar la base de datos para la tabla `Inscription`
-- 

INSERT INTO `Inscription` VALUES (2, 1, 2, '2023-11-10', 320, 1, 2);

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `Monitor`
-- 

CREATE TABLE `Monitor` (
  `id` int(64) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL,
  `surname` varchar(64) NOT NULL,
  `special` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

-- 
-- Volcar la base de datos para la tabla `Monitor`
-- 

INSERT INTO `Monitor` VALUES (1, 'Ana', 'Gonzalez', 1);
INSERT INTO `Monitor` VALUES (2, 'Carlos', 'Martinez', 0);
INSERT INTO `Monitor` VALUES (3, 'Elena', 'Rodriguez', 1);
INSERT INTO `Monitor` VALUES (4, 'Miguel', 'Lopez', 0);
INSERT INTO `Monitor` VALUES (5, 'Sofia', 'Fernandez', 1);
INSERT INTO `Monitor` VALUES (6, 'Alejandro', 'Hernandez', 0);
INSERT INTO `Monitor` VALUES (7, 'Isabel', 'Gomez', 1);
INSERT INTO `Monitor` VALUES (8, 'Javier', 'Diaz', 0);
INSERT INTO `Monitor` VALUES (9, 'Carmen', 'Perez', 1);
INSERT INTO `Monitor` VALUES (10, 'Daniel', 'Ruiz', 0);