import model as model

#Insertamos las funciones de los diferentes botones
def eventOpenFile(self):
    model.openFile(self)

def eventSave(self):
    model.save(self)    

