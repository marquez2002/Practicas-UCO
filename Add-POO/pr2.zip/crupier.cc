/**
 * @file crupier.cc
 * @author Gonzalo Márquez (i02matog@uco.es)
 * @brief definition of the methods of class Crupier
*/

#include "crupier.h"
