//hello-world.cc
//A program that prints the inmortal saying "hello world"
#include <iostream>

int main(){
	std::cout<<"hello world\n";
}