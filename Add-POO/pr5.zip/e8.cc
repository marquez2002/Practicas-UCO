#include <iostream>
#include "dados.h"
using namespace std;

int main(void){
   Dados a,b;
   cin>>a;
   cin>>b;
   cout<<a<<b<<endl;
}