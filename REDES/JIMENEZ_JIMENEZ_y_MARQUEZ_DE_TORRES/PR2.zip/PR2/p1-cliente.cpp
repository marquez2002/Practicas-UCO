#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <time.h>
#include <arpa/inet.h>


int main(int argc, char* const argv[]){

   //Descriptor del socket y buffer de datos
   int sdcliente;
   struct sockaddr_in sockname;
   char buffer[250];
   socklen_t len_sockname;
   fd_set readfds, auxfds;
   int salida;
   int fin = 0;

   struct sockaddr_in Servidor;  
   socklen_t Longitud_Servidor;


   //Abrimos el socket
   sdcliente = socket(AF_INET, SOCK_STREAM, 0);
   if (sdcliente == -1){
      perror("–ERR. No se puede abrir el socket cliente\n");
      exit(1);
   }


   //	Se rellenan los campos de la estructura con la IP del servidor y el puerto del servicio que solicitamos

   sockname.sin_family = AF_INET;
   sockname.sin_port = htons(2050);
   sockname.sin_addr.s_addr = inet_addr(argv[1]);


   //Solicitamos conexión con el servidor
   len_sockname = sizeof(sockname);
	
	if (connect(sdcliente, (struct sockaddr *)&sockname, len_sockname) == -1)
	{
		perror ("Error de conexión");
		exit(1);
	}
   char cadena2[256];
   scanf("%s", cadena2);
   int recibido = recvfrom (sdcliente, (char *)&cadena2, sizeof(cadena2), 0, (struct sockaddr *) &Servidor, &Longitud_Servidor);


   printf("Una vez se haya conectado al servidor introduzca:\n");
   printf(" - Para registrarse por primera vez: \n");
   printf("   REGISTRO -u usuario -p password\n");
   printf(" - Para iniciar sesión: \n");
   printf("   USUARIO usuario\n");
}
   
