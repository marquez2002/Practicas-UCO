#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>
#include <unistd.h>
#include <time.h>
#include <arpa/inet.h>
#include <regex.h>
#include <ctype.h>
#include "p1servidor.h"

#define MSG_SIZE 250
#define MAX_CLIENTS 30

void manejador(int signum);
void salirCliente(int socket, fd_set * readfds, int * numClientes, int arrayClientes[]);
void imprimirMatriz(int* matriz);
int comprobarGanador(int** matriz);
void exitHandler(int signum);
void closedClient(int socket, fd_set *readfds, int *numClientes, int arrayClientes[]);
bool encontrarNombre(char nombre, int* arrayClientes, int numClientes);


//Variable programa
int Server, newServer;
struct sockaddr_in sockname, from;
char buffer[MSG_SIZE];
socklen_t from_len;
fd_set readfds, auxfds;
int salida;
int arrayClientes[MAX_CLIENTS];
int numClientes = 0;

//Contadores
int i,j,k;
int recibidos;
char identificador[MSG_SIZE];

int on, ret;

regex_t regex;
int result;


int main(){

    result=regcomp(&regex, "REGISTRO -u \\w* -p \\w*", REG_EXTENDED);
    //loadSystem();

    //Inicializacion de los socket y preparacion del servidor para la lectura
    Server=socket(AF_INET, SOCK_STREAM, 0);
    if(Server==-1){
        perror("-ERR. No se puede abrir el socket cliente.\n");
        exit(1);
    }

    on=1;
    ret=setsockopt(Server, SOL_SOCKET, SO_REUSEADDR, &on, sizeof(on));

    
	sockname.sin_family=AF_INET;
	sockname.sin_port=htons(2060);
	sockname.sin_addr.s_addr=INADDR_ANY;

	if (bind (Server, (struct sockaddr *) &sockname, sizeof(sockname))==-1){
		perror("-ERR. No se ha podido realizar la operación bind");
		exit(1);
	}
	
    from_len = sizeof (from);

	if(listen(Server,1) == -1){
		perror("-ERR. No se ha podido realizar la operación de listen");
		exit(1);
	}
    
    //Inicializar los conjuntos fd_set
    FD_ZERO(&readfds);
    FD_ZERO(&auxfds);
    FD_SET(Server,&readfds);
    FD_SET(0,&readfds);

    while(1){        
    //Esperamos recibir mensajes de los clientes (nuevas conexiones o mensajes de los clientes ya conectados)
        auxfds = readfds;
        salida = select(FD_SETSIZE,&auxfds,NULL,NULL,NULL);
        if(salida > 0){
            for(i=0; i<FD_SETSIZE; i++){
                //Buscamos el socket por el que se ha establecido la comunicación
                if(FD_ISSET(i, &auxfds)) {
                    if(i == Server){
                        if((newServer = accept(Server, (struct sockaddr *)&from, &from_len)) == -1){
                            perror("-ERR. No se han podido aceptar peticiones.\n");
                        }
                        else{
                            if(numClientes < MAX_CLIENTS){
                                arrayClientes[numClientes] = newServer;
                                numClientes++;
                                FD_SET(newServer,&readfds);
                                strcpy(buffer, "+Ok. Usuario conectado\n");
                                send(newServer,buffer,sizeof(buffer),0);
                            }
                            else{
                                bzero(buffer,sizeof(buffer));
                                strcpy(buffer,"Demasiados clientes conectados\n");
                                send(newServer,buffer,sizeof(buffer),0);
                                close(newServer);
                            }
                        }
                    }
                }


                else if (i == 0){
                    //Se ha introducido información de teclado
                    bzero(buffer, sizeof(buffer));
                    fgets(buffer, sizeof(buffer),stdin);

                    //Controlar si se ha introducido "SALIR", cerrando todos los sockets y finalmente saliendo del servidor. (implementar)
                    if(strcmp(buffer,"SALIR\n")==0){
                       exitHandler(SIGINT); 
                    }    
                } 

                else{
                    bzero(buffer,sizeof(buffer));
                    recibidos = recv(i,buffer,sizeof(buffer),0);

                    if(recibidos > 0){
                        result=regexec(&regex, buffer, 0, NULL, 0);
                        if(strcmp(buffer,"SALIR\n")==0){
                            closedClient(i, &readfds, &numClientes, arrayClientes);
                        }
                        else if(!result){
                            User user;
                            char* aux;
                            const char *name;
                            const char *password;
                            const char *flag;
                            aux=strtok(buffer, " ");
                            aux=strtok(NULL, " ");
                            aux=strtok(NULL, " ");
                            name=aux;
                            aux=strtok(NULL, " ");
                            flag=aux;
                            aux=strtok(NULL, " ");
                            password=aux;

                            if(encontrarNombre(*name, User user)){
                                strcpy(buffer, "-ERR. Usuario ya registrado.\n");
                                send(i, buffer, sizeof(buffer), 0);
                            }
                            else{
                                User.setUserName(name);
                                User.setUserPassword(password);
                                strcpy(buffer, "+Ok. Usuario registrado.\n");
                                send(i, buffer, sizeof(buffer), 0);
                            }
                        }
                        else if(strncmp(buffer, "USUARIO ", strlen("USUARIO "))==0){
                            if(strncmp(buffer, "USUARIO \n", strlen("USUARIO \n"))==0){
                                strcpy(buffer, "-ERR. No se ha podido completar el login.\n");
                                send(i, buffer, sizeof(buffer), 0);
                            }
                            else{
                                char* aux;
                                aux=strtok(buffer, " ");
                                aux=strtok(NULL, "\n");
                                if(encontrarNombre(*name, ))
                                
                            }
                        }
                        
                    } 
                }
            }
        }
    }
}
