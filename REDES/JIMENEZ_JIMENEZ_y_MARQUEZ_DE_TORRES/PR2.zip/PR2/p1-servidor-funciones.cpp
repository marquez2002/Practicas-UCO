#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>
#include <unistd.h>
#include <time.h>
#include <arpa/inet.h>
#include <regex.h>
#include <ctype.h>
#include "p1servidor.h"

void salirCliente(int socket, fd_set * readfds, int * numClientes, int arrayClientes[]){
  
    char buffer[250];
    int j;
    
    close(socket);
    FD_CLR(socket,readfds);
    
//Re-estructurar el array de clientes
    for (j = 0; j < (*numClientes) - 1; j++){
        if (arrayClientes[j] == socket){
            break;
        }
    }
    for (; j < (*numClientes) - 1; j++){
        (arrayClientes[j] = arrayClientes[j+1]);
    }
    (*numClientes)--;
    
    
    bzero(buffer,sizeof(buffer));
    sprintf(buffer,"Desconexión del cliente: %d\n",socket);
    
    for(j=0; j<(*numClientes); j++){
        if(arrayClientes[j] != socket){
            send(arrayClientes[j],buffer,sizeof(buffer),0);
        }
    }
}


void manejador (int signum){
    printf("\nSe ha recibido la señal sigint\n");
    signal(SIGINT,manejador);
}

void imprimirMatriz(int** matriz){
    printf("| 1 | 2 | 3 | 4 | 5 | 6 | 7 |");
    for(int i=0; i<7; i++){
        printf("| ");
        for(int j=0; j<7; j++){
            if(matriz[i][j]==0){
                printf("  |");
            }
            if(matriz[i][j]==1){
                printf(" x |");
            }
            if(matriz[i][j]==2){
                printf(" o |");
                if(j==7){
                    printf("\n");
                }
            }
        }
    }
}

int comprobarGanador(int** matriz){

    //Cuatro en raya en fila
    for(int i=0; i<4; i++){
        for(int j=0; j<7;j++){
            if(matriz[i][j]==matriz[i+1][j]==matriz[i+2][j]==matriz[i+3][j]==1){
                return 1;
            }
        }
    }
    for(int i=0; i<4; i++){
        for(int j=0; j<7;j++){
            if(matriz[i][j]==matriz[i+1][j]==matriz[i+2][j]==matriz[i+3][j]==2){
                return 2;
            }
        }
    }

    //Cuatro en raya en columna
    for(int i=0; i<7; i++){
        for(int j=0; j<4;j++){
            if(matriz[i][j]==matriz[i][j+1]==matriz[i][j+2]==matriz[i][j+3]==1){
                return 1;
            }
        }
    }
    for(int i=0; i<7; i++){
        for(int j=0; j<4;j++){
            if(matriz[i][j]==matriz[i][j+1]==matriz[i][j+2]==matriz[i][j+3]==2){
                return 2;
            }
        }
    }

    //Cuatro en raya en diagonal
    for(int i=0; i<4; i++){
        for(int j=0; j<4;j++){
            if(matriz[i][j]==matriz[i+1][j+1]==matriz[i+2][j+2]==matriz[i+3][j+3]==1){
                return 1;
            }
        }
    }
    for(int i=0; i<4; i++){
        for(int j=0; j<4;j++){
            if(matriz[i][j]==matriz[i+1][j+1]==matriz[i+2][j+2]==matriz[i+3][j+3]==2){
                return 2;
            }
        }
    }

    //Cuatro en raya en diagonal invertido
    for(int i=3; i<7; i++){
        for(int j=3; j<7;j++){
            if(matriz[i][j]==matriz[i-1][j-1]==matriz[i-2][j-2]==matriz[i-3][j-3]==1){
                return 1;
            }
        }
    }
    for(int i=3; i<7; i++){
        for(int j=3; j<7;j++){
            if(matriz[i][j]==matriz[i-1][j-1]==matriz[i-2][j-2]==matriz[i-3][j-3]==2){
                return 2;
            }
        }
    }
}

bool encontrarNombre(char nombre, User user){
    for(int i=0; i< user.size(); i++){
        if(strcmp(user[i].name_, nombre)==0){
            return true;
        }
    }
    return false;
}


